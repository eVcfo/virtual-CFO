# Virtual CFO Financial App

## How to Run

1. Install dependencies:

```bash
cd backend
npm install
cd ../
npm install
```

2. Simulate backend build (done already in `/backend/dist`)

3. Run both backend and frontend:

```bash
# Terminal 1
cd backend
npm start

# Terminal 2
cd project
npm run dev
```

Frontend is served at: http://localhost:5173  
Backend API is served at: http://localhost:5000/api

---
