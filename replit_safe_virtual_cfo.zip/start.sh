#!/bin/bash

# Install frontend and backend dependencies
cd backend && npm install && cd ..
npm install

# Start backend in background
cd backend && npm run build && npm start &

# Start frontend
cd ..
npm run dev