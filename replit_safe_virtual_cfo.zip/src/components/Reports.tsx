import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  FileText, 
  Download, 
  Calendar, 
  Filter,
  BarChart3,
  PieChart,
  TrendingUp,
  Users,
  DollarSign,
  Package,
  Clock,
  Eye
} from 'lucide-react';

const reportTypes = [
  {
    id: 'financial',
    title: 'Financial Reports',
    description: 'P&L, Balance Sheet, Cash Flow statements',
    icon: DollarSign,
    color: 'text-lime-accent',
    bgColor: 'bg-lime-accent/10',
    reports: [
      'Profit & Loss Statement',
      'Balance Sheet',
      'Cash Flow Statement',
      'Financial Ratios Analysis'
    ]
  },
  {
    id: 'operational',
    title: 'Operational Reports',
    description: 'Efficiency, productivity, and performance metrics',
    icon: BarChart3,
    color: 'text-blue-400',
    bgColor: 'bg-blue-400/10',
    reports: [
      'Department Performance',
      'Process Efficiency',
      'Resource Utilization',
      'Quality Metrics'
    ]
  },
  {
    id: 'hr',
    title: 'HR & Personnel',
    description: 'Employee performance and workforce analytics',
    icon: Users,
    color: 'text-purple-400',
    bgColor: 'bg-purple-400/10',
    reports: [
      'Employee Performance',
      'Attendance Analysis',
      'Training Effectiveness',
      'Compensation Analysis'
    ]
  },
  {
    id: 'inventory',
    title: 'Inventory Reports',
    description: 'Stock levels, turnover, and supply chain metrics',
    icon: Package,
    color: 'text-orange-400',
    bgColor: 'bg-orange-400/10',
    reports: [
      'Inventory Turnover',
      'Stock Level Analysis',
      'Supplier Performance',
      'Demand Forecasting'
    ]
  }
];

const recentReports = [
  {
    id: 1,
    name: 'Q4 2024 Financial Summary',
    type: 'Financial',
    generatedDate: '2024-01-15',
    size: '2.4 MB',
    format: 'PDF',
    status: 'completed'
  },
  {
    id: 2,
    name: 'Operational Efficiency Report',
    type: 'Operational',
    generatedDate: '2024-01-14',
    size: '1.8 MB',
    format: 'Excel',
    status: 'completed'
  },
  {
    id: 3,
    name: 'Employee Performance Analysis',
    type: 'HR',
    generatedDate: '2024-01-13',
    size: '3.2 MB',
    format: 'PDF',
    status: 'generating'
  },
  {
    id: 4,
    name: 'Inventory Turnover Report',
    type: 'Inventory',
    generatedDate: '2024-01-12',
    size: '1.5 MB',
    format: 'Excel',
    status: 'completed'
  }
];

const scheduledReports = [
  {
    name: 'Monthly Financial Summary',
    frequency: 'Monthly',
    nextRun: '2024-02-01',
    recipients: 3
  },
  {
    name: 'Weekly Operations Dashboard',
    frequency: 'Weekly',
    nextRun: '2024-01-22',
    recipients: 5
  },
  {
    name: 'Quarterly Performance Review',
    frequency: 'Quarterly',
    nextRun: '2024-04-01',
    recipients: 8
  }
];

export const Reports: React.FC = () => {
  const [selectedReportType, setSelectedReportType] = useState('financial');
  const [dateRange, setDateRange] = useState('last-month');

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <FileText className="w-5 h-5 text-lime-accent" />;
      case 'generating':
        return <div className="w-5 h-5 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />;
      default:
        return <FileText className="w-5 h-5 text-light-text-secondary dark:text-dark-text-secondary" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-lime-accent bg-lime-accent/10';
      case 'generating':
        return 'text-blue-400 bg-blue-400/10';
      default:
        return 'text-light-text-secondary dark:text-dark-text-secondary bg-light-glass dark:bg-dark-glass';
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-4xl font-bold text-light-text dark:text-dark-text font-editorial">
            Reports & Analytics
          </h1>
          <p className="text-light-text-secondary dark:text-dark-text-secondary mt-2">
            Generate comprehensive reports and schedule automated analytics
          </p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center space-x-2 bg-lime-accent text-light-base dark:text-dark-base px-6 py-3 rounded-xl font-medium hover:shadow-glow transition-all"
        >
          <FileText className="w-5 h-5" />
          <span>Generate Report</span>
        </motion.button>
      </motion.div>

      {/* Report Types */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {reportTypes.map((type, index) => (
          <motion.div
            key={type.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            onClick={() => setSelectedReportType(type.id)}
            className={`p-6 rounded-xl cursor-pointer transition-all ${
              selectedReportType === type.id
                ? 'bg-lime-accent/10 border-2 border-lime-accent/30'
                : 'bg-light-surface/50 dark:bg-dark-surface/50 border border-light-border dark:border-dark-border hover:border-lime-accent/30'
            }`}
          >
            <div className={`p-3 rounded-full ${type.bgColor} mb-4 w-fit`}>
              <type.icon className={`w-6 h-6 ${type.color}`} />
            </div>
            <h3 className="text-lg font-bold text-light-text dark:text-dark-text font-editorial mb-2">
              {type.title}
            </h3>
            <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-4">
              {type.description}
            </p>
            <div className="space-y-1">
              {type.reports.slice(0, 3).map((report, reportIndex) => (
                <div key={reportIndex} className="text-xs text-light-text dark:text-dark-text">
                  • {report}
                </div>
              ))}
              {type.reports.length > 3 && (
                <div className="text-xs text-lime-accent">
                  +{type.reports.length - 3} more
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Report Generation */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6"
      >
        <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
          Generate Custom Report
        </h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Report Configuration */}
          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-light-text dark:text-dark-text mb-2">
                  Report Type
                </label>
                <select className="w-full bg-light-glass dark:bg-dark-glass border border-light-border dark:border-dark-border rounded-lg px-3 py-2 text-light-text dark:text-dark-text focus:outline-none focus:border-lime-accent/50">
                  <option>Financial Summary</option>
                  <option>Operational Dashboard</option>
                  <option>Performance Analysis</option>
                  <option>Custom Report</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-light-text dark:text-dark-text mb-2">
                  Date Range
                </label>
                <select 
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value)}
                  className="w-full bg-light-glass dark:bg-dark-glass border border-light-border dark:border-dark-border rounded-lg px-3 py-2 text-light-text dark:text-dark-text focus:outline-none focus:border-lime-accent/50"
                >
                  <option value="last-week">Last Week</option>
                  <option value="last-month">Last Month</option>
                  <option value="last-quarter">Last Quarter</option>
                  <option value="last-year">Last Year</option>
                  <option value="custom">Custom Range</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-light-text dark:text-dark-text mb-2">
                Include Sections
              </label>
              <div className="grid grid-cols-2 gap-3">
                {[
                  'Executive Summary',
                  'Financial Metrics',
                  'Operational KPIs',
                  'Trend Analysis',
                  'Comparative Data',
                  'Recommendations'
                ].map((section, index) => (
                  <label key={index} className="flex items-center space-x-2">
                    <input 
                      type="checkbox" 
                      defaultChecked={index < 4}
                      className="rounded border-light-border dark:border-dark-border text-lime-accent focus:ring-lime-accent"
                    />
                    <span className="text-sm text-light-text dark:text-dark-text">{section}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-light-text dark:text-dark-text mb-2">
                Output Format
              </label>
              <div className="flex space-x-4">
                {['PDF', 'Excel', 'PowerPoint'].map((format) => (
                  <label key={format} className="flex items-center space-x-2">
                    <input 
                      type="radio" 
                      name="format" 
                      value={format}
                      defaultChecked={format === 'PDF'}
                      className="text-lime-accent focus:ring-lime-accent"
                    />
                    <span className="text-sm text-light-text dark:text-dark-text">{format}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Preview */}
          <div className="bg-light-glass dark:bg-dark-glass rounded-lg p-4">
            <h4 className="font-semibold text-light-text dark:text-dark-text mb-4">Report Preview</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4 text-lime-accent" />
                <span className="text-light-text dark:text-dark-text">Period: {dateRange.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
              </div>
              <div className="flex items-center space-x-2">
                <BarChart3 className="w-4 h-4 text-blue-400" />
                <span className="text-light-text dark:text-dark-text">6 sections included</span>
              </div>
              <div className="flex items-center space-x-2">
                <FileText className="w-4 h-4 text-purple-400" />
                <span className="text-light-text dark:text-dark-text">Estimated: 15-20 pages</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-orange-400" />
                <span className="text-light-text dark:text-dark-text">Generation time: ~3 minutes</span>
              </div>
            </div>
            
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full mt-6 bg-lime-accent text-light-base dark:text-dark-base py-3 rounded-lg font-medium hover:shadow-glow transition-all"
            >
              Generate Report
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* Recent Reports & Scheduled Reports */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Reports */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6"
        >
          <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
            Recent Reports
          </h3>
          <div className="space-y-4">
            {recentReports.map((report, index) => (
              <motion.div
                key={report.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="flex items-center justify-between p-4 bg-light-glass dark:bg-dark-glass rounded-lg hover:bg-lime-accent/5 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  {getStatusIcon(report.status)}
                  <div>
                    <h4 className="font-medium text-light-text dark:text-dark-text">{report.name}</h4>
                    <div className="flex items-center space-x-2 text-sm text-light-text-secondary dark:text-dark-text-secondary">
                      <span>{report.generatedDate}</span>
                      <span>•</span>
                      <span>{report.size}</span>
                      <span>•</span>
                      <span>{report.format}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(report.status)}`}>
                    {report.status}
                  </span>
                  {report.status === 'completed' && (
                    <div className="flex items-center space-x-1">
                      <button className="p-2 hover:bg-light-surface dark:hover:bg-dark-surface rounded-lg transition-colors">
                        <Eye className="w-4 h-4 text-light-text-secondary dark:text-dark-text-secondary" />
                      </button>
                      <button className="p-2 hover:bg-light-surface dark:hover:bg-dark-surface rounded-lg transition-colors">
                        <Download className="w-4 h-4 text-light-text-secondary dark:text-dark-text-secondary" />
                      </button>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Scheduled Reports */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial">
              Scheduled Reports
            </h3>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="text-lime-accent hover:bg-lime-accent/10 px-3 py-1 rounded-lg transition-colors text-sm"
            >
              + Add Schedule
            </motion.button>
          </div>
          
          <div className="space-y-4">
            {scheduledReports.map((report, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="p-4 bg-light-glass dark:bg-dark-glass rounded-lg"
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-light-text dark:text-dark-text">{report.name}</h4>
                  <span className="px-2 py-1 bg-blue-400/10 text-blue-400 rounded-full text-xs">
                    {report.frequency}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm text-light-text-secondary dark:text-dark-text-secondary">
                  <span>Next run: {report.nextRun}</span>
                  <span>{report.recipients} recipients</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};