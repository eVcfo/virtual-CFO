import React, { useState } from 'react';
import KPISection from './KPISection';
import AISuggestions from './AISuggestions';
import axios from 'axios';

const UploadAndAnalyze = () => {
  const [file, setFile] = useState<File | null>(null);
  const [insights, setInsights] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    setLoading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post('/api/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setInsights(response.data);
    } catch (error) {
      console.error('Upload failed', error);
      alert('Upload or analysis failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-xl font-bold">Upload Financial Data</h2>
      <input type="file" onChange={handleFileChange} className="border p-2" />
      <button
        onClick={handleUpload}
        className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
        disabled={loading || !file}
      >
        {loading ? 'Uploading...' : 'Upload & Analyze'}
      </button>

      {insights && (
  <div className='space-y-6'>
    <KPISection insights={insights.financialInsights} />
        <div className="mt-6 space-y-4">
          <h3 className="text-lg font-semibold">Financial Insights</h3>
          <pre className="bg-gray-100 p-4 rounded overflow-x-auto">
            {JSON.stringify(insights.financialInsights, null, 2)}
          </pre>

          <h3 className="text-lg font-semibold">Operational Insights</h3>
          <pre className="bg-gray-100 p-4 rounded overflow-x-auto">
            {JSON.stringify(insights.operationalInsights, null, 2)}
          </pre>
            <AISuggestions insights={insights} />
  </div>
</div>
      )}
        <AISuggestions insights={insights} />
  </div>
</div>
  );
};

export default UploadAndAnalyze;