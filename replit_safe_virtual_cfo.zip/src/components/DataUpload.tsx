import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Upload, 
  FileText, 
  Database, 
  CheckCircle, 
  AlertCircle,
  Download,
  Trash2,
  Eye,
  X
} from 'lucide-react';

const supportedFormats = [
  { type: 'CSV', description: 'Comma-separated values', icon: FileText },
  { type: 'Excel', description: 'Microsoft Excel files (.xlsx, .xls)', icon: FileText },
  { type: 'JSON', description: 'JavaScript Object Notation', icon: Database },
  { type: 'XML', description: 'Extensible Markup Language', icon: Database }
];

const uploadedFilesData = [
  {
    id: 1,
    name: 'Q4_Financial_Data.xlsx',
    size: '2.4 MB',
    uploadDate: '2024-01-15',
    status: 'processed',
    type: 'Financial',
    records: 1247
  },
  {
    id: 2,
    name: 'Employee_Performance.csv',
    size: '856 KB',
    uploadDate: '2024-01-14',
    status: 'processing',
    type: 'HR',
    records: 342
  },
  {
    id: 3,
    name: 'Inventory_Data.json',
    size: '1.8 MB',
    uploadDate: '2024-01-13',
    status: 'processed',
    type: 'Operations',
    records: 2156
  },
  {
    id: 4,
    name: 'Sales_Report.csv',
    size: '3.2 MB',
    uploadDate: '2024-01-12',
    status: 'error',
    type: 'Sales',
    records: 0
  }
];

const dataTemplates = [
  {
    name: 'Financial Statement Template',
    description: 'Standard format for P&L, Balance Sheet, and Cash Flow data',
    fields: ['Date', 'Account', 'Debit', 'Credit', 'Category']
  },
  {
    name: 'Employee Performance Template',
    description: 'Template for tracking employee KPIs and performance metrics',
    fields: ['Employee ID', 'Department', 'KPI', 'Target', 'Actual']
  },
  {
    name: 'Inventory Management Template',
    description: 'Format for inventory levels, turnover, and stock data',
    fields: ['SKU', 'Product Name', 'Quantity', 'Cost', 'Location']
  },
  {
    name: 'Sales Data Template',
    description: 'Template for sales transactions and customer data',
    fields: ['Date', 'Customer ID', 'Product', 'Quantity', 'Revenue']
  }
];

export const DataUpload: React.FC = () => {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploadedFiles, setUploadedFiles] = useState(uploadedFilesData);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const files = Array.from(e.dataTransfer.files);
      setSelectedFiles(prev => [...prev, ...files]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      setSelectedFiles(prev => [...prev, ...files]);
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const simulateFileProcessing = (file: File): Promise<void> => {
    return new Promise((resolve) => {
      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 20;
        setUploadProgress(prev => ({ ...prev, [file.name]: Math.min(progress, 100) }));
        
        if (progress >= 100) {
          clearInterval(interval);
          resolve();
        }
      }, 200);
    });
  };

  const handleUpload = async () => {
    if (selectedFiles.length === 0) return;
    
    setIsUploading(true);
    
    for (const file of selectedFiles) {
      try {
        // Validate file before upload
        await processFile(file);
        
        // Upload file to backend
        const formData = new FormData();
        formData.append('file', file);
        formData.append('dataType', getFileType(file.name).toLowerCase());
        formData.append('period', 'monthly');

        const response = await fetch('/api/data/upload', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
          },
          body: formData,
        });

        const responseText = await response.text();
        let result;
        
        try {
          result = JSON.parse(responseText);
        } catch (parseError) {
          console.error('Failed to parse response:', responseText);
          throw new Error(`Server returned invalid response: ${response.status} ${response.statusText}`);
        }

        if (!response.ok) {
          throw new Error(result.message || `Upload failed: ${response.statusText}`);
        }
        
        // Simulate upload progress
        await simulateFileProcessing(file);
        
        // Add to uploaded files list
        const newUploadedFile = {
          id: Date.now() + Math.random(),
          name: file.name,
          size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
          uploadDate: new Date().toISOString().split('T')[0],
          status: result.success ? 'processed' as const : 'error' as const,
          type: getFileType(file.name),
          records: result.data?.recordsProcessed || 0
        };
        
        setUploadedFiles(prev => [newUploadedFile, ...prev]);
        
        // Trigger analytics update if successful
        if (result.success) {
          await triggerAnalyticsUpdate(result.data.recordId, getFileType(file.name).toLowerCase());
        }
      } catch (error) {
        console.error(`Error uploading file ${file.name}:`, error);
        
        // Add failed file to list
        const failedFile = {
          id: Date.now() + Math.random(),
          name: file.name,
          size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
          uploadDate: new Date().toISOString().split('T')[0],
          status: 'error' as const,
          type: getFileType(file.name),
          records: 0,
          error: error instanceof Error ? error.message : 'Upload failed'
        };
        
        setUploadedFiles(prev => [failedFile, ...prev]);
      }
    }
    
    // Clear selected files and reset states
    setSelectedFiles([]);
    setUploadProgress({});
    setIsUploading(false);
  };

  const triggerAnalyticsUpdate = async (recordId: string, dataType: string) => {
    try {
      if (!recordId) {
        console.warn('No record ID provided for analytics update');
        return;
      }
      
      const response = await fetch('/api/analytics/process-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
        },
        body: JSON.stringify({
          fileId: recordId,
          dataType: dataType
        }),
      });

      if (response.ok) {
        console.log('Analytics updated successfully');
        // You could emit an event here to update the dashboard in real-time
        window.dispatchEvent(new CustomEvent('analyticsUpdated', { detail: { dataType } }));
      } else {
        const errorText = await response.text();
        console.error('Analytics update failed:', errorText);
      }
    } catch (error) {
      console.error('Error updating analytics:', error);
    }
  };

  const processFile = async (file: File): Promise<void> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const content = e.target?.result as string;
          
          // Basic file validation
          if (!content || content.trim().length === 0) {
            throw new Error('File is empty or unreadable');
          }
          
          // Validate file type and content
          const fileExtension = file.name.split('.').pop()?.toLowerCase();
          
          switch (fileExtension) {
            case 'csv':
              validateCSVContent(content);
              break;
            case 'json':
              validateJSONContent(content);
              break;
            case 'xml':
              validateXMLContent(content);
              break;
            case 'xlsx':
            case 'xls':
              // For Excel files, we'll accept them as valid for now
              // In a real implementation, you'd use a library like xlsx to parse
              break;
            default:
              throw new Error(`Unsupported file type: ${fileExtension}`);
          }
          
          resolve();
        } catch (error) {
          reject(error);
        }
      };
      
      reader.onerror = () => {
        reject(new Error('Failed to read file'));
      };
      
      // Read file based on type
      const fileExtension = file.name.split('.').pop()?.toLowerCase();
      if (fileExtension === 'xlsx' || fileExtension === 'xls') {
        reader.readAsArrayBuffer(file);
      } else {
        reader.readAsText(file);
      }
    });
  };

  const validateCSVContent = (content: string) => {
    const lines = content.split('\n').filter(line => line.trim());
    if (lines.length < 2) {
      throw new Error('CSV file must have at least a header row and one data row');
    }
    
    const headerColumns = lines[0].split(',').length;
    if (headerColumns < 2) {
      throw new Error('CSV file must have at least 2 columns');
    }
  };

  const validateJSONContent = (content: string) => {
    try {
      const data = JSON.parse(content);
      if (!Array.isArray(data) && typeof data !== 'object') {
        throw new Error('JSON file must contain an array or object');
      }
      if (Array.isArray(data) && data.length === 0) {
        throw new Error('JSON array cannot be empty');
      }
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error('Invalid JSON format');
      }
      throw error;
    }
  };

  const validateXMLContent = (content: string) => {
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(content, 'text/xml');
      const parseError = doc.querySelector('parsererror');
      if (parseError) {
        throw new Error('Invalid XML format');
      }
    } catch (error) {
      throw new Error('Failed to parse XML file');
    }
  };

  const getFileType = (filename: string): string => {
    if (filename.toLowerCase().includes('financial') || filename.toLowerCase().includes('revenue') || filename.toLowerCase().includes('profit')) {
      return 'Financial';
    } else if (filename.toLowerCase().includes('employee') || filename.toLowerCase().includes('hr') || filename.toLowerCase().includes('staff')) {
      return 'HR';
    } else if (filename.toLowerCase().includes('inventory') || filename.toLowerCase().includes('stock') || filename.toLowerCase().includes('supply')) {
      return 'Operations';
    } else if (filename.toLowerCase().includes('sales') || filename.toLowerCase().includes('customer') || filename.toLowerCase().includes('marketing')) {
      return 'Sales';
    }
    return 'General';
  };

  const deleteUploadedFile = (id: number) => {
    setUploadedFiles(prev => prev.filter(file => file.id !== id));
  };

  const downloadTemplate = (templateName: string) => {
    // Create a sample CSV content based on template
    let csvContent = '';
    
    switch (templateName) {
      case 'Financial Statement Template':
        csvContent = 'Date,Account,Debit,Credit,Category\n2024-01-01,Revenue,0,10000,Income\n2024-01-01,Expenses,5000,0,Operating';
        break;
      case 'Employee Performance Template':
        csvContent = 'Employee ID,Department,KPI,Target,Actual\nEMP001,Sales,Revenue,50000,52000\nEMP002,Marketing,Leads,100,120';
        break;
      case 'Inventory Management Template':
        csvContent = 'SKU,Product Name,Quantity,Cost,Location\nSKU001,Product A,100,25.50,Warehouse A\nSKU002,Product B,75,15.25,Warehouse B';
        break;
      case 'Sales Data Template':
        csvContent = 'Date,Customer ID,Product,Quantity,Revenue\n2024-01-01,CUST001,Product A,2,51.00\n2024-01-01,CUST002,Product B,1,15.25';
        break;
      default:
        csvContent = 'Column1,Column2,Column3\nValue1,Value2,Value3';
    }
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${templateName.replace(' Template', '')}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'processed':
        return <CheckCircle className="w-5 h-5 text-lime-accent" />;
      case 'processing':
        return <div className="w-5 h-5 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />;
      case 'error':
        return <AlertCircle className="w-5 h-5 text-red-400" />;
      default:
        return <FileText className="w-5 h-5 text-light-text-secondary dark:text-dark-text-secondary" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'processed':
        return 'text-lime-accent bg-lime-accent/10';
      case 'processing':
        return 'text-blue-400 bg-blue-400/10';
      case 'error':
        return 'text-red-400 bg-red-400/10';
      default:
        return 'text-light-text-secondary dark:text-dark-text-secondary bg-light-glass dark:bg-dark-glass';
    }
  };

  const getFileIcon = (filename: string) => {
    const extension = filename.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'csv':
        return <FileText className="w-5 h-5 text-lime-accent" />;
      case 'xlsx':
      case 'xls':
        return <FileText className="w-5 h-5 text-blue-400" />;
      case 'json':
        return <Database className="w-5 h-5 text-purple-400" />;
      case 'xml':
        return <Database className="w-5 h-5 text-orange-400" />;
      default:
        return <FileText className="w-5 h-5 text-light-text-secondary dark:text-dark-text-secondary" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold text-light-text dark:text-dark-text font-editorial">
          Data Upload & Management
        </h1>
        <p className="text-light-text-secondary dark:text-dark-text-secondary mt-2">
          Upload and manage your financial and operational data files
        </p>
      </motion.div>

      {/* Upload Area */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-8"
      >
        <div
          className={`border-2 border-dashed rounded-xl p-12 text-center transition-all ${
            dragActive 
              ? 'border-lime-accent bg-lime-accent/5' 
              : 'border-light-border dark:border-dark-border hover:border-lime-accent/50'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <Upload className="w-16 h-16 text-lime-accent mx-auto mb-4" />
          <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-2">
            Drop files here or click to upload
          </h3>
          <p className="text-light-text-secondary dark:text-dark-text-secondary mb-6">
            Support for CSV, Excel, JSON, and XML files up to 50MB
          </p>
          
          <input
            type="file"
            multiple
            accept=".csv,.xlsx,.xls,.json,.xml"
            onChange={handleFileSelect}
            className="hidden"
            id="file-upload"
          />
          <label
            htmlFor="file-upload"
            className="inline-flex items-center space-x-2 bg-lime-accent text-light-base dark:text-dark-base px-6 py-3 rounded-xl font-medium hover:shadow-glow transition-all cursor-pointer"
          >
            <Upload className="w-5 h-5" />
            <span>Choose Files</span>
          </label>
        </div>

        {/* Selected Files */}
        {selectedFiles.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            transition={{ duration: 0.3 }}
            className="mt-6 space-y-3"
          >
            <h4 className="font-semibold text-light-text dark:text-dark-text">Selected Files:</h4>
            {selectedFiles.map((file, index) => (
              <div key={`${file.name}-${index}`} className="flex items-center justify-between p-3 bg-light-glass dark:bg-dark-glass rounded-lg">
                <div className="flex items-center space-x-3">
                  {getFileIcon(file.name)}
                  <div>
                    <p className="font-medium text-light-text dark:text-dark-text">{file.name}</p>
                    <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                    <p className="text-xs text-light-text-secondary dark:text-dark-text-secondary">
                      Type: {getFileType(file.name)}
                    </p>
                    {isUploading && uploadProgress[file.name] !== undefined && (
                      <div className="mt-2">
                        <div className="w-full bg-light-glass dark:bg-dark-glass rounded-full h-1">
                          <div 
                            className="h-1 bg-lime-accent rounded-full transition-all duration-300"
                            style={{ width: `${uploadProgress[file.name]}%` }}
                          />
                        </div>
                        <p className="text-xs text-lime-accent mt-1">{Math.round(uploadProgress[file.name])}% uploaded</p>
                      </div>
                    )}
                  </div>
                </div>
                {!isUploading && (
                  <button
                    onClick={() => removeFile(index)}
                    className="p-2 hover:bg-red-400/10 rounded-lg transition-colors"
                  >
                    <X className="w-4 h-4 text-red-400" />
                  </button>
                )}
              </div>
            ))}
            <motion.button
              onClick={handleUpload}
              disabled={isUploading}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`w-full py-3 rounded-xl font-medium transition-all ${
                isUploading 
                  ? 'bg-gray-400 cursor-not-allowed' 
                  : 'bg-lime-accent hover:shadow-glow'
              } text-light-base dark:text-dark-base`}
            >
              {isUploading ? 'Uploading...' : `Upload ${selectedFiles.length} File${selectedFiles.length > 1 ? 's' : ''}`}
            </motion.button>
          </motion.div>
        )}
      </motion.div>

      {/* Supported Formats */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6"
      >
        <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
          Supported File Formats
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {supportedFormats.map((format, index) => (
            <motion.div
              key={format.type}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="p-4 bg-light-glass dark:bg-dark-glass rounded-lg text-center"
            >
              <format.icon className="w-8 h-8 text-lime-accent mx-auto mb-3" />
              <h4 className="font-semibold text-light-text dark:text-dark-text mb-1">{format.type}</h4>
              <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary">
                {format.description}
              </p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Uploaded Files */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6"
      >
        <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
          Recently Uploaded Files
        </h3>
        <div className="space-y-4">
          {uploadedFiles.map((file, index) => (
            <motion.div
              key={file.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="flex items-center justify-between p-4 bg-light-glass dark:bg-dark-glass rounded-lg hover:bg-lime-accent/5 transition-colors"
            >
              <div className="flex items-center space-x-4">
                {getStatusIcon(file.status)}
                <div>
                  <h4 className="font-medium text-light-text dark:text-dark-text">{file.name}</h4>
                  <div className="flex items-center space-x-4 text-sm text-light-text-secondary dark:text-dark-text-secondary">
                    <span>{file.size}</span>
                    <span>•</span>
                    <span>{file.uploadDate}</span>
                    <span>•</span>
                    <span>{file.records} records</span>
                    {file.error && (
                      <>
                        <span>•</span>
                        <span className="text-red-400">{file.error}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(file.status)}`}>
                  {file.status}
                </span>
                <span className="px-3 py-1 bg-blue-400/10 text-blue-400 rounded-full text-xs font-medium">
                  {file.type}
                </span>
                <div className="flex items-center space-x-1">
                  <button className="p-2 hover:bg-light-surface dark:hover:bg-dark-surface rounded-lg transition-colors">
                    <Eye className="w-4 h-4 text-light-text-secondary dark:text-dark-text-secondary" />
                  </button>
                  <button className="p-2 hover:bg-light-surface dark:hover:bg-dark-surface rounded-lg transition-colors">
                    <Download className="w-4 h-4 text-light-text-secondary dark:text-dark-text-secondary" />
                  </button>
                  <button 
                    onClick={() => deleteUploadedFile(file.id)}
                    className="p-2 hover:bg-red-400/10 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Data Templates */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6"
      >
        <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
          Data Templates
        </h3>
        <p className="text-light-text-secondary dark:text-dark-text-secondary mb-6">
          Download standardized templates to ensure your data is formatted correctly
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {dataTemplates.map((template, index) => (
            <motion.div
              key={template.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="p-6 bg-light-glass dark:bg-dark-glass rounded-lg"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h4 className="font-semibold text-light-text dark:text-dark-text mb-2">
                    {template.name}
                  </h4>
                  <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary">
                    {template.description}
                  </p>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => downloadTemplate(template.name)}
                  className="p-2 bg-lime-accent/10 text-lime-accent rounded-lg hover:bg-lime-accent/20 transition-colors"
                >
                  <Download className="w-5 h-5" />
                </motion.button>
              </div>
              
              <div className="space-y-2">
                <span className="text-xs text-light-text-secondary dark:text-dark-text-secondary">Required Fields:</span>
                <div className="flex flex-wrap gap-2">
                  {template.fields.map((field, fieldIndex) => (
                    <span
                      key={fieldIndex}
                      className="px-2 py-1 bg-light-surface dark:bg-dark-surface text-xs rounded-full text-light-text dark:text-dark-text"
                    >
                      {field}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};