import React from 'react';

const KPISection = ({ insights }: { insights: any }) => {
  if (!insights) return null;

  const { revenueGrowth, netProfitMargin, currentRatio, debtEquityRatio } = insights;

  const kpis = [
    { title: "Revenue Growth", value: revenueGrowth?.toFixed(2) + "%" },
    { title: "Net Profit Margin", value: netProfitMargin?.toFixed(2) + "%" },
    { title: "Current Ratio", value: currentRatio?.toFixed(2) },
    { title: "Debt-Equity Ratio", value: debtEquityRatio?.toFixed(2) }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {kpis.map((kpi, idx) => (
        <div key={idx} className="bg-white shadow-md p-4 rounded-lg">
          <h4 className="text-sm text-gray-500">{kpi.title}</h4>
          <p className="text-xl font-bold">{kpi.value}</p>
        </div>
      ))}
    </div>
  );
};

export default KPISection;