import React from 'react';
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Users, 
  Package, 
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';

const kpiData = [
  {
    title: 'Total Revenue',
    value: '$2.4M',
    change: '+12.5%',
    trend: 'up',
    icon: DollarSign,
    color: 'text-lime-accent',
    bgColor: 'bg-lime-accent/10'
  },
  {
    title: 'Operating Margin',
    value: '18.2%',
    change: '+2.1%',
    trend: 'up',
    icon: TrendingUp,
    color: 'text-blue-400',
    bgColor: 'bg-blue-400/10'
  },
  {
    title: 'Customer Acquisition',
    value: '1,247',
    change: '-3.2%',
    trend: 'down',
    icon: Users,
    color: 'text-orange-400',
    bgColor: 'bg-orange-400/10'
  },
  {
    title: 'Inventory Turnover',
    value: '4.8x',
    change: '+8.7%',
    trend: 'up',
    icon: Package,
    color: 'text-purple-400',
    bgColor: 'bg-purple-400/10'
  }
];

const recentAlerts = [
  {
    type: 'warning',
    message: 'Cash flow projection shows potential shortage in Q3',
    time: '2 hours ago',
    severity: 'medium'
  },
  {
    type: 'success',
    message: 'Revenue target exceeded by 15% this quarter',
    time: '4 hours ago',
    severity: 'low'
  },
  {
    type: 'error',
    message: 'Operational costs increased by 8% vs budget',
    time: '6 hours ago',
    severity: 'high'
  }
];

const quickActions = [
  { label: 'Generate Monthly Report', action: 'reports' },
  { label: 'Upload Financial Data', action: 'upload' },
  { label: 'View Cash Flow Forecast', action: 'forecasting' },
  { label: 'Analyze P&L Statement', action: 'financial' }
];

export const Dashboard: React.FC = () => {
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
    
    // Listen for analytics updates
    const handleAnalyticsUpdate = () => {
      fetchDashboardData();
    };
    
    window.addEventListener('analyticsUpdated', handleAnalyticsUpdate);
    
    // Set up periodic refresh
    const interval = setInterval(fetchDashboardData, 30000); // Refresh every 30 seconds
    
    return () => {
      window.removeEventListener('analyticsUpdated', handleAnalyticsUpdate);
      clearInterval(interval);
    };
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await fetch('/api/analytics/dashboard', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
        },
      });
      
      if (response.ok) {
        const result = await response.json();
        setDashboardData(result.data);
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-lime-accent border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold text-light-text dark:text-dark-text font-editorial">
          Financial Analytics Dashboard
        </h1>
        <p className="text-light-text-secondary dark:text-dark-text-secondary mt-2">
          Real-time insights into your company's financial and operational performance
        </p>
      </motion.div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiData.map((kpi, index) => (
          <motion.div
            key={kpi.title}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            whileHover={{ scale: 1.02, y: -5 }}
            className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6 hover:border-lime-accent/30 transition-all hover:shadow-glow duration-300"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-full ${kpi.bgColor}`}>
                <kpi.icon className={`w-6 h-6 ${kpi.color}`} />
              </div>
              <div className={`flex items-center space-x-1 ${
                kpi.trend === 'up' ? 'text-lime-accent' : 'text-red-400'
              }`}>
                {kpi.trend === 'up' ? (
                  <ArrowUpRight className="w-4 h-4" />
                ) : (
                  <ArrowDownRight className="w-4 h-4" />
                )}
                <span className="text-sm font-medium">{kpi.change}</span>
              </div>
            </div>
            <div>
              <h3 className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-1">
                {kpi.title}
              </h3>
              <motion.p
                initial={{ scale: 0.8 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.3, delay: index * 0.1 + 0.2 }}
                className="text-3xl font-bold text-light-text dark:text-dark-text font-editorial"
              >
                {kpi.value}
              </motion.p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Revenue Trend Chart */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="lg:col-span-2 bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6 transition-colors duration-300"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial">
              Revenue Trend
            </h3>
            <div className="flex space-x-2">
              <button className="px-3 py-1 text-xs bg-lime-accent/10 text-lime-accent rounded-full">
                12M
              </button>
              <button className="px-3 py-1 text-xs text-light-text-secondary dark:text-dark-text-secondary hover:bg-light-glass dark:hover:bg-dark-glass rounded-full transition-colors">
                6M
              </button>
              <button className="px-3 py-1 text-xs text-light-text-secondary dark:text-dark-text-secondary hover:bg-light-glass dark:hover:bg-dark-glass rounded-full transition-colors">
                3M
              </button>
            </div>
          </div>
          
          {/* Simplified Chart Visualization */}
          <div className="h-64 flex items-end space-x-2">
            {[65, 78, 82, 88, 95, 89, 92, 98, 105, 112, 108, 115].map((height, index) => (
              <motion.div
                key={index}
                initial={{ height: 0 }}
                animate={{ height: `${height}%` }}
                transition={{ duration: 0.8, delay: 0.6 + index * 0.1 }}
                className="flex-1 bg-gradient-to-t from-lime-accent/20 to-lime-accent/60 rounded-t-sm min-h-[20px]"
              />
            ))}
          </div>
          
          <div className="flex justify-between mt-4 text-xs text-light-text-secondary dark:text-dark-text-secondary">
            {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map(month => (
              <span key={month}>{month}</span>
            ))}
          </div>
        </motion.div>

        {/* Alerts & Quick Actions */}
        <div className="space-y-6">
          {/* Alerts */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6 transition-colors duration-300"
          >
            <div className="flex items-center space-x-2 mb-4">
              <AlertTriangle className="w-5 h-5 text-orange-400" />
              <h3 className="text-lg font-bold text-light-text dark:text-dark-text font-editorial">
                Recent Alerts
              </h3>
            </div>
            
            <div className="space-y-3">
              {recentAlerts.map((alert, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.7 + index * 0.1 }}
                  className={`p-3 rounded-lg border-l-4 ${
                    alert.severity === 'high' 
                      ? 'border-red-400 bg-red-400/10' 
                      : alert.severity === 'medium'
                      ? 'border-orange-400 bg-orange-400/10'
                      : 'border-lime-accent bg-lime-accent/10'
                  }`}
                >
                  <p className="text-sm text-light-text dark:text-dark-text mb-1">
                    {alert.message}
                  </p>
                  <p className="text-xs text-light-text-secondary dark:text-dark-text-secondary">
                    {alert.time}
                  </p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6 transition-colors duration-300"
          >
            <h3 className="text-lg font-bold text-light-text dark:text-dark-text font-editorial mb-4">
              Quick Actions
            </h3>
            
            <div className="space-y-2">
              {quickActions.map((action, index) => (
                <motion.button
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.8 + index * 0.1 }}
                  whileHover={{ scale: 1.02, x: 5 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full text-left p-3 rounded-lg hover:bg-light-glass dark:hover:bg-dark-glass transition-all group"
                >
                  <span className="text-sm text-light-text dark:text-dark-text group-hover:text-lime-accent transition-colors">
                    {action.label}
                  </span>
                </motion.button>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Performance Metrics */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.7 }}
        className="bg-gradient-to-r from-light-surface/80 to-light-glass dark:from-dark-surface/80 dark:to-dark-glass border border-light-border dark:border-dark-border rounded-2xl p-8 shadow-glass transition-colors duration-300"
      >
        <h3 className="text-2xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
          Performance Overview
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="relative w-24 h-24 mx-auto mb-4">
              <svg className="w-24 h-24 transform -rotate-90">
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  className="text-light-glass dark:text-dark-glass"
                />
                <motion.circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  strokeLinecap="round"
                  className="text-lime-accent"
                  initial={{ strokeDasharray: "0 251.2" }}
                  animate={{ strokeDasharray: "188.4 251.2" }}
                  transition={{ duration: 1.5, delay: 0.8 }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xl font-bold text-lime-accent">75%</span>
              </div>
            </div>
            <h4 className="font-semibold text-light-text dark:text-dark-text">Profit Margin</h4>
            <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary">vs Target</p>
          </div>
          
          <div className="text-center">
            <div className="relative w-24 h-24 mx-auto mb-4">
              <svg className="w-24 h-24 transform -rotate-90">
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  className="text-light-glass dark:text-dark-glass"
                />
                <motion.circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  strokeLinecap="round"
                  className="text-blue-400"
                  initial={{ strokeDasharray: "0 251.2" }}
                  animate={{ strokeDasharray: "213.52 251.2" }}
                  transition={{ duration: 1.5, delay: 1.0 }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xl font-bold text-blue-400">85%</span>
              </div>
            </div>
            <h4 className="font-semibold text-light-text dark:text-dark-text">Efficiency Score</h4>
            <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary">Operational</p>
          </div>
          
          <div className="text-center">
            <div className="relative w-24 h-24 mx-auto mb-4">
              <svg className="w-24 h-24 transform -rotate-90">
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  className="text-light-glass dark:text-dark-glass"
                />
                <motion.circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  strokeLinecap="round"
                  className="text-purple-400"
                  initial={{ strokeDasharray: "0 251.2" }}
                  animate={{ strokeDasharray: "225.36 251.2" }}
                  transition={{ duration: 1.5, delay: 1.2 }}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xl font-bold text-purple-400">92%</span>
              </div>
            </div>
            <h4 className="font-semibold text-light-text dark:text-dark-text">Cash Health</h4>
            <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary">Liquidity Ratio</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};