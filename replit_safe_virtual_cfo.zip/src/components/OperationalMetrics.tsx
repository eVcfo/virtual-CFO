import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  Package, 
  Clock, 
  Target, 
  TrendingUp,
  TrendingDown,
  Activity,
  Zap,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

const operationalKPIs = [
  {
    title: 'Employee Productivity',
    value: '94.2%',
    change: '+3.1%',
    trend: 'up',
    icon: Users,
    color: 'text-blue-400',
    bgColor: 'bg-blue-400/10'
  },
  {
    title: 'Inventory Turnover',
    value: '6.8x',
    change: '+0.5x',
    trend: 'up',
    icon: Package,
    color: 'text-lime-accent',
    bgColor: 'bg-lime-accent/10'
  },
  {
    title: 'Order Fulfillment Time',
    value: '2.3 days',
    change: '-0.4 days',
    trend: 'up',
    icon: Clock,
    color: 'text-purple-400',
    bgColor: 'bg-purple-400/10'
  },
  {
    title: 'Quality Score',
    value: '98.7%',
    change: '+1.2%',
    trend: 'up',
    icon: Target,
    color: 'text-orange-400',
    bgColor: 'bg-orange-400/10'
  }
];

const departmentMetrics = [
  {
    department: 'Production',
    efficiency: 92,
    capacity: 85,
    quality: 96,
    status: 'excellent'
  },
  {
    department: 'Sales',
    efficiency: 88,
    capacity: 78,
    quality: 94,
    status: 'good'
  },
  {
    department: 'Customer Service',
    efficiency: 95,
    capacity: 82,
    quality: 98,
    status: 'excellent'
  },
  {
    department: 'Logistics',
    efficiency: 87,
    capacity: 91,
    quality: 89,
    status: 'good'
  },
  {
    department: 'IT',
    efficiency: 91,
    capacity: 88,
    quality: 97,
    status: 'excellent'
  }
];

const processMetrics = [
  { name: 'Order Processing', efficiency: 94, bottleneck: false },
  { name: 'Inventory Management', efficiency: 87, bottleneck: true },
  { name: 'Quality Control', efficiency: 96, bottleneck: false },
  { name: 'Shipping & Delivery', efficiency: 89, bottleneck: false },
  { name: 'Customer Support', efficiency: 92, bottleneck: false },
  { name: 'Returns Processing', efficiency: 78, bottleneck: true }
];

export const OperationalMetrics: React.FC = () => {
  const [selectedDepartment, setSelectedDepartment] = useState('Production');
  const [operationalData, setOperationalData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOperationalData();
    
    // Listen for analytics updates
    const handleAnalyticsUpdate = (event: any) => {
      if (event.detail.dataType === 'operational' || event.detail.dataType === 'hr') {
        fetchOperationalData();
      }
    };
    
    window.addEventListener('analyticsUpdated', handleAnalyticsUpdate);
    
    return () => {
      window.removeEventListener('analyticsUpdated', handleAnalyticsUpdate);
    };
  }, []);

  const fetchOperationalData = async () => {
    try {
      const response = await fetch('/api/operational/metrics', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
        },
      });
      
      if (response.ok) {
        const result = await response.json();
        setOperationalData(result.data);
      }
    } catch (error) {
      console.error('Error fetching operational data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold text-light-text dark:text-dark-text font-editorial">
          Operational Metrics
        </h1>
        <p className="text-light-text-secondary dark:text-dark-text-secondary mt-2">
          Monitor and optimize operational efficiency across all departments
        </p>
      </motion.div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {operationalKPIs.map((kpi, index) => (
          <motion.div
            key={kpi.title}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            whileHover={{ scale: 1.02, y: -5 }}
            className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6 hover:border-lime-accent/30 transition-all hover:shadow-glow duration-300"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-full ${kpi.bgColor}`}>
                <kpi.icon className={`w-6 h-6 ${kpi.color}`} />
              </div>
              <div className={`flex items-center space-x-1 ${
                kpi.trend === 'up' ? 'text-lime-accent' : 'text-red-400'
              }`}>
                {kpi.trend === 'up' ? (
                  <TrendingUp className="w-4 h-4" />
                ) : (
                  <TrendingDown className="w-4 h-4" />
                )}
                <span className="text-sm font-medium">{kpi.change}</span>
              </div>
            </div>
            <div>
              <h3 className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-1">
                {kpi.title}
              </h3>
              <motion.p
                initial={{ scale: 0.8 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.3, delay: index * 0.1 + 0.2 }}
                className="text-3xl font-bold text-light-text dark:text-dark-text font-editorial"
              >
                {kpi.value}
              </motion.p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Department Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Department List */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6"
        >
          <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
            Department Performance
          </h3>
          <div className="space-y-3">
            {departmentMetrics.map((dept, index) => (
              <motion.div
                key={dept.department}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                onClick={() => setSelectedDepartment(dept.department)}
                className={`p-4 rounded-lg cursor-pointer transition-all ${
                  selectedDepartment === dept.department
                    ? 'bg-lime-accent/10 border border-lime-accent/30'
                    : 'bg-light-glass dark:bg-dark-glass hover:bg-lime-accent/5'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-light-text dark:text-dark-text">
                    {dept.department}
                  </span>
                  <div className="flex items-center space-x-1">
                    {dept.status === 'excellent' ? (
                      <CheckCircle className="w-4 h-4 text-lime-accent" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-orange-400" />
                    )}
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      dept.status === 'excellent' 
                        ? 'bg-lime-accent/20 text-lime-accent' 
                        : 'bg-orange-400/20 text-orange-400'
                    }`}>
                      {dept.status}
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <span className="text-light-text-secondary dark:text-dark-text-secondary">Efficiency</span>
                    <div className="font-bold text-light-text dark:text-dark-text">{dept.efficiency}%</div>
                  </div>
                  <div>
                    <span className="text-light-text-secondary dark:text-dark-text-secondary">Capacity</span>
                    <div className="font-bold text-light-text dark:text-dark-text">{dept.capacity}%</div>
                  </div>
                  <div>
                    <span className="text-light-text-secondary dark:text-dark-text-secondary">Quality</span>
                    <div className="font-bold text-light-text dark:text-dark-text">{dept.quality}%</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Department Details */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6"
        >
          <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
            {selectedDepartment} Details
          </h3>
          
          {departmentMetrics
            .filter(dept => dept.department === selectedDepartment)
            .map((dept, index) => (
              <div key={dept.department} className="space-y-6">
                {/* Performance Circles */}
                <div className="grid grid-cols-3 gap-6">
                  {[
                    { label: 'Efficiency', value: dept.efficiency, color: 'text-lime-accent' },
                    { label: 'Capacity', value: dept.capacity, color: 'text-blue-400' },
                    { label: 'Quality', value: dept.quality, color: 'text-purple-400' }
                  ].map((metric, metricIndex) => (
                    <div key={metric.label} className="text-center">
                      <div className="relative w-20 h-20 mx-auto mb-3">
                        <svg className="w-20 h-20 transform -rotate-90">
                          <circle
                            cx="40"
                            cy="40"
                            r="32"
                            stroke="currentColor"
                            strokeWidth="6"
                            fill="none"
                            className="text-light-glass dark:text-dark-glass"
                          />
                          <motion.circle
                            cx="40"
                            cy="40"
                            r="32"
                            stroke="currentColor"
                            strokeWidth="6"
                            fill="none"
                            strokeLinecap="round"
                            className={metric.color}
                            initial={{ strokeDasharray: "0 201.06" }}
                            animate={{ strokeDasharray: `${metric.value * 2.01} 201.06` }}
                            transition={{ duration: 1.5, delay: metricIndex * 0.2 }}
                          />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className={`text-lg font-bold ${metric.color}`}>
                            {metric.value}%
                          </span>
                        </div>
                      </div>
                      <h4 className="font-medium text-light-text dark:text-dark-text">
                        {metric.label}
                      </h4>
                    </div>
                  ))}
                </div>

                {/* Recent Activity */}
                <div className="space-y-3">
                  <h4 className="font-semibold text-light-text dark:text-dark-text">Recent Activity</h4>
                  {[
                    'Completed quarterly efficiency review',
                    'Implemented new quality control measures',
                    'Optimized workflow processes',
                    'Updated capacity planning models'
                  ].map((activity, activityIndex) => (
                    <motion.div
                      key={activityIndex}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: activityIndex * 0.1 }}
                      className="flex items-center space-x-3 p-3 bg-light-glass dark:bg-dark-glass rounded-lg"
                    >
                      <Activity className="w-4 h-4 text-lime-accent" />
                      <span className="text-sm text-light-text dark:text-dark-text">{activity}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            ))}
        </motion.div>
      </div>

      {/* Process Efficiency */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.6 }}
        className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial">
            Process Efficiency Analysis
          </h3>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-lime-accent rounded-full"></div>
              <span className="text-sm text-light-text-secondary dark:text-dark-text-secondary">Optimal</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-400 rounded-full"></div>
              <span className="text-sm text-light-text-secondary dark:text-dark-text-secondary">Bottleneck</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {processMetrics.map((process, index) => (
            <motion.div
              key={process.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className={`p-4 rounded-lg border ${
                process.bottleneck 
                  ? 'border-red-400/30 bg-red-400/5' 
                  : 'border-light-border dark:border-dark-border bg-light-glass dark:bg-dark-glass'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-light-text dark:text-dark-text">{process.name}</h4>
                {process.bottleneck ? (
                  <AlertCircle className="w-5 h-5 text-red-400" />
                ) : (
                  <Zap className="w-5 h-5 text-lime-accent" />
                )}
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-light-text-secondary dark:text-dark-text-secondary">Efficiency</span>
                  <span className={`font-bold ${process.bottleneck ? 'text-red-400' : 'text-lime-accent'}`}>
                    {process.efficiency}%
                  </span>
                </div>
                <div className="w-full bg-light-glass dark:bg-dark-glass rounded-full h-2">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${process.efficiency}%` }}
                    transition={{ duration: 1, delay: index * 0.1 + 0.3 }}
                    className={`h-2 rounded-full ${
                      process.bottleneck ? 'bg-red-400' : 'bg-lime-accent'
                    }`}
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};