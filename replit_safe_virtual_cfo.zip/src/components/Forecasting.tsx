import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Target, 
  TrendingUp, 
  TrendingDown, 
  Calendar,
  BarChart3,
  LineChart,
  PieChart,
  AlertTriangle,
  CheckCircle,
  DollarSign,
  Users,
  Package
} from 'lucide-react';

const forecastMetrics = [
  {
    title: 'Revenue Forecast',
    current: '$2.4M',
    projected: '$3.1M',
    change: '+29.2%',
    confidence: 87,
    trend: 'up',
    icon: DollarSign,
    color: 'text-lime-accent',
    bgColor: 'bg-lime-accent/10'
  },
  {
    title: 'Customer Growth',
    current: '1,247',
    projected: '1,580',
    change: '+26.7%',
    confidence: 82,
    trend: 'up',
    icon: Users,
    color: 'text-blue-400',
    bgColor: 'bg-blue-400/10'
  },
  {
    title: 'Inventory Needs',
    current: '4.8x',
    projected: '5.2x',
    change: '+8.3%',
    confidence: 91,
    trend: 'up',
    icon: Package,
    color: 'text-purple-400',
    bgColor: 'bg-purple-400/10'
  }
];

const scenarios = [
  {
    name: 'Conservative',
    probability: 70,
    revenue: '$2.8M',
    growth: '+16.7%',
    color: 'text-orange-400',
    bgColor: 'bg-orange-400/10'
  },
  {
    name: 'Most Likely',
    probability: 85,
    revenue: '$3.1M',
    growth: '+29.2%',
    color: 'text-lime-accent',
    bgColor: 'bg-lime-accent/10'
  },
  {
    name: 'Optimistic',
    probability: 45,
    revenue: '$3.6M',
    growth: '+50.0%',
    color: 'text-blue-400',
    bgColor: 'bg-blue-400/10'
  }
];

const riskFactors = [
  {
    factor: 'Market Competition',
    impact: 'High',
    probability: 65,
    mitigation: 'Enhance product differentiation',
    status: 'monitoring'
  },
  {
    factor: 'Supply Chain Disruption',
    impact: 'Medium',
    probability: 35,
    mitigation: 'Diversify supplier base',
    status: 'mitigated'
  },
  {
    factor: 'Economic Downturn',
    impact: 'High',
    probability: 25,
    mitigation: 'Build cash reserves',
    status: 'prepared'
  },
  {
    factor: 'Regulatory Changes',
    impact: 'Low',
    probability: 40,
    mitigation: 'Monitor compliance requirements',
    status: 'monitoring'
  }
];

const monthlyProjections = [
  { month: 'Jan', actual: 180000, projected: 185000 },
  { month: 'Feb', actual: 195000, projected: 200000 },
  { month: 'Mar', actual: 210000, projected: 215000 },
  { month: 'Apr', actual: null, projected: 230000 },
  { month: 'May', actual: null, projected: 245000 },
  { month: 'Jun', actual: null, projected: 260000 },
  { month: 'Jul', actual: null, projected: 275000 },
  { month: 'Aug', actual: null, projected: 290000 },
  { month: 'Sep', actual: null, projected: 305000 },
  { month: 'Oct', actual: null, projected: 320000 },
  { month: 'Nov', actual: null, projected: 335000 },
  { month: 'Dec', actual: null, projected: 350000 }
];

export const Forecasting: React.FC = () => {
  const [selectedTimeframe, setSelectedTimeframe] = useState('12-months');
  const [selectedScenario, setSelectedScenario] = useState('Most Likely');

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return 'text-lime-accent';
    if (confidence >= 60) return 'text-orange-400';
    return 'text-red-400';
  };

  const getRiskStatusIcon = (status: string) => {
    switch (status) {
      case 'mitigated':
        return <CheckCircle className="w-4 h-4 text-lime-accent" />;
      case 'prepared':
        return <CheckCircle className="w-4 h-4 text-blue-400" />;
      default:
        return <AlertTriangle className="w-4 h-4 text-orange-400" />;
    }
  };

  const getRiskStatusColor = (status: string) => {
    switch (status) {
      case 'mitigated':
        return 'text-lime-accent bg-lime-accent/10';
      case 'prepared':
        return 'text-blue-400 bg-blue-400/10';
      default:
        return 'text-orange-400 bg-orange-400/10';
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-4xl font-bold text-light-text dark:text-dark-text font-editorial">
            Financial Forecasting
          </h1>
          <p className="text-light-text-secondary dark:text-dark-text-secondary mt-2">
            Predictive analytics and scenario planning for strategic decision making
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <select 
            value={selectedTimeframe}
            onChange={(e) => setSelectedTimeframe(e.target.value)}
            className="bg-light-glass dark:bg-dark-glass border border-light-border dark:border-dark-border rounded-lg px-4 py-2 text-light-text dark:text-dark-text focus:outline-none focus:border-lime-accent/50"
          >
            <option value="6-months">6 Months</option>
            <option value="12-months">12 Months</option>
            <option value="24-months">24 Months</option>
          </select>
        </div>
      </motion.div>

      {/* Forecast Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {forecastMetrics.map((metric, index) => (
          <motion.div
            key={metric.title}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            whileHover={{ scale: 1.02, y: -5 }}
            className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6 hover:border-lime-accent/30 transition-all hover:shadow-glow duration-300"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-full ${metric.bgColor}`}>
                <metric.icon className={`w-6 h-6 ${metric.color}`} />
              </div>
              <div className={`flex items-center space-x-1 ${
                metric.trend === 'up' ? 'text-lime-accent' : 'text-red-400'
              }`}>
                {metric.trend === 'up' ? (
                  <TrendingUp className="w-4 h-4" />
                ) : (
                  <TrendingDown className="w-4 h-4" />
                )}
                <span className="text-sm font-medium">{metric.change}</span>
              </div>
            </div>
            
            <div className="space-y-3">
              <h3 className="text-sm text-light-text-secondary dark:text-dark-text-secondary">
                {metric.title}
              </h3>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-light-text dark:text-dark-text">Current</span>
                  <span className="font-medium text-light-text dark:text-dark-text">{metric.current}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-light-text dark:text-dark-text">Projected</span>
                  <span className="font-bold text-lime-accent">{metric.projected}</span>
                </div>
              </div>
              
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-light-text-secondary dark:text-dark-text-secondary">Confidence</span>
                  <span className={`text-xs font-medium ${getConfidenceColor(metric.confidence)}`}>
                    {metric.confidence}%
                  </span>
                </div>
                <div className="w-full bg-light-glass dark:bg-dark-glass rounded-full h-1">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${metric.confidence}%` }}
                    transition={{ duration: 1, delay: index * 0.1 + 0.3 }}
                    className={`h-1 rounded-full ${
                      metric.confidence >= 80 ? 'bg-lime-accent' :
                      metric.confidence >= 60 ? 'bg-orange-400' : 'bg-red-400'
                    }`}
                  />
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Forecast Chart & Scenarios */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Forecast Chart */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="lg:col-span-2 bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial">
              Revenue Projection
            </h3>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-lime-accent rounded-full"></div>
                <span className="text-sm text-light-text-secondary dark:text-dark-text-secondary">Actual</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-400 rounded-full"></div>
                <span className="text-sm text-light-text-secondary dark:text-dark-text-secondary">Projected</span>
              </div>
            </div>
          </div>
          
          {/* Chart */}
          <div className="h-64 flex items-end space-x-1">
            {monthlyProjections.map((data, index) => (
              <div key={data.month} className="flex-1 flex flex-col items-center space-y-1">
                <div className="w-full flex flex-col items-end space-y-1" style={{ height: '240px' }}>
                  {data.actual && (
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: `${(data.actual / 350000) * 100}%` }}
                      transition={{ duration: 0.8, delay: index * 0.1 }}
                      className="w-full bg-lime-accent/60 rounded-t-sm min-h-[4px]"
                    />
                  )}
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: `${(data.projected / 350000) * 100}%` }}
                    transition={{ duration: 0.8, delay: index * 0.1 + 0.2 }}
                    className={`w-full rounded-t-sm min-h-[4px] ${
                      data.actual ? 'bg-blue-400/40 border-t-2 border-blue-400' : 'bg-blue-400/60'
                    }`}
                  />
                </div>
                <span className="text-xs text-light-text-secondary dark:text-dark-text-secondary">
                  {data.month}
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Scenarios */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6"
        >
          <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
            Scenario Analysis
          </h3>
          
          <div className="space-y-4">
            {scenarios.map((scenario, index) => (
              <motion.div
                key={scenario.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                onClick={() => setSelectedScenario(scenario.name)}
                className={`p-4 rounded-lg cursor-pointer transition-all ${
                  selectedScenario === scenario.name
                    ? `${scenario.bgColor} border border-current`
                    : 'bg-light-glass dark:bg-dark-glass hover:bg-lime-accent/5'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className={`font-semibold ${
                    selectedScenario === scenario.name ? scenario.color : 'text-light-text dark:text-dark-text'
                  }`}>
                    {scenario.name}
                  </h4>
                  <span className="text-xs text-light-text-secondary dark:text-dark-text-secondary">
                    {scenario.probability}% likely
                  </span>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-light-text-secondary dark:text-dark-text-secondary">Revenue</span>
                    <span className="font-bold text-light-text dark:text-dark-text">{scenario.revenue}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-light-text-secondary dark:text-dark-text-secondary">Growth</span>
                    <span className={`font-medium ${scenario.color}`}>{scenario.growth}</span>
                  </div>
                </div>
                
                <div className="mt-3">
                  <div className="w-full bg-light-glass dark:bg-dark-glass rounded-full h-1">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${scenario.probability}%` }}
                      transition={{ duration: 1, delay: index * 0.1 + 0.5 }}
                      className={`h-1 rounded-full ${scenario.color.replace('text-', 'bg-')}`}
                    />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Risk Analysis */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6"
      >
        <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
          Risk Assessment & Mitigation
        </h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {riskFactors.map((risk, index) => (
            <motion.div
              key={risk.factor}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="p-4 bg-light-glass dark:bg-dark-glass rounded-lg"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="font-semibold text-light-text dark:text-dark-text mb-1">
                    {risk.factor}
                  </h4>
                  <div className="flex items-center space-x-3 text-sm">
                    <span className={`px-2 py-1 rounded-full ${
                      risk.impact === 'High' ? 'bg-red-400/20 text-red-400' :
                      risk.impact === 'Medium' ? 'bg-orange-400/20 text-orange-400' :
                      'bg-lime-accent/20 text-lime-accent'
                    }`}>
                      {risk.impact} Impact
                    </span>
                    <span className="text-light-text-secondary dark:text-dark-text-secondary">
                      {risk.probability}% probability
                    </span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {getRiskStatusIcon(risk.status)}
                  <span className={`px-2 py-1 rounded-full text-xs ${getRiskStatusColor(risk.status)}`}>
                    {risk.status}
                  </span>
                </div>
              </div>
              
              <p className="text-sm text-light-text dark:text-dark-text mb-3">
                <span className="font-medium">Mitigation: </span>
                {risk.mitigation}
              </p>
              
              <div className="w-full bg-light-glass dark:bg-dark-glass rounded-full h-1">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${risk.probability}%` }}
                  transition={{ duration: 1, delay: index * 0.1 + 0.6 }}
                  className={`h-1 rounded-full ${
                    risk.probability > 60 ? 'bg-red-400' :
                    risk.probability > 30 ? 'bg-orange-400' : 'bg-lime-accent'
                  }`}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};