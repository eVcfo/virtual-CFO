import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  PieChart, 
  BarChart3,
  Calculator,
  FileText,
  Download
} from 'lucide-react';

const financialMetrics = [
  {
    category: 'Profitability',
    metrics: [
      { name: 'Gross Profit Margin', value: '42.5%', change: '+2.1%', trend: 'up' },
      { name: 'Net Profit Margin', value: '18.2%', change: '+1.8%', trend: 'up' },
      { name: 'EBITDA Margin', value: '28.7%', change: '+3.2%', trend: 'up' },
      { name: 'Return on Assets', value: '12.4%', change: '-0.5%', trend: 'down' }
    ]
  },
  {
    category: 'Liquidity',
    metrics: [
      { name: 'Current Ratio', value: '2.1', change: '+0.3', trend: 'up' },
      { name: 'Quick Ratio', value: '1.8', change: '+0.2', trend: 'up' },
      { name: 'Cash Ratio', value: '0.9', change: '-0.1', trend: 'down' },
      { name: 'Working Capital', value: '$1.2M', change: '+$150K', trend: 'up' }
    ]
  },
  {
    category: 'Efficiency',
    metrics: [
      { name: 'Asset Turnover', value: '1.4x', change: '+0.1x', trend: 'up' },
      { name: 'Inventory Turnover', value: '6.2x', change: '+0.8x', trend: 'up' },
      { name: 'Receivables Turnover', value: '8.5x', change: '-0.3x', trend: 'down' },
      { name: 'Days Sales Outstanding', value: '43 days', change: '+2 days', trend: 'down' }
    ]
  }
];

const revenueBreakdown = [
  { category: 'Product Sales', amount: 1680000, percentage: 70, color: 'bg-lime-accent' },
  { category: 'Services', amount: 480000, percentage: 20, color: 'bg-blue-400' },
  { category: 'Subscriptions', amount: 240000, percentage: 10, color: 'bg-purple-400' }
];

const expenseBreakdown = [
  { category: 'Cost of Goods Sold', amount: 960000, percentage: 40, color: 'bg-red-400' },
  { category: 'Operating Expenses', amount: 720000, percentage: 30, color: 'bg-orange-400' },
  { category: 'Marketing', amount: 360000, percentage: 15, color: 'bg-pink-400' },
  { category: 'R&D', amount: 240000, percentage: 10, color: 'bg-indigo-400' },
  { category: 'Other', amount: 120000, percentage: 5, color: 'bg-gray-400' }
];

export const FinancialAnalysis: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [financialData, setFinancialData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFinancialData();
    
    // Listen for analytics updates
    const handleAnalyticsUpdate = (event: any) => {
      if (event.detail.dataType === 'financial') {
        fetchFinancialData();
      }
    };
    
    window.addEventListener('analyticsUpdated', handleAnalyticsUpdate);
    
    return () => {
      window.removeEventListener('analyticsUpdated', handleAnalyticsUpdate);
    };
  }, []);

  const fetchFinancialData = async () => {
    try {
      const response = await fetch('/api/financial/analysis', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
        },
      });
      
      if (response.ok) {
        const result = await response.json();
        setFinancialData(result.data);
      }
    } catch (error) {
      console.error('Error fetching financial data:', error);
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'ratios', label: 'Financial Ratios', icon: Calculator },
    { id: 'breakdown', label: 'Revenue & Expenses', icon: PieChart },
    { id: 'statements', label: 'Financial Statements', icon: FileText }
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-4xl font-bold text-light-text dark:text-dark-text font-editorial">
            Financial Analysis
          </h1>
          <p className="text-light-text-secondary dark:text-dark-text-secondary mt-2">
            Comprehensive analysis of financial performance and health
          </p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center space-x-2 bg-lime-accent text-light-base dark:text-dark-base px-6 py-3 rounded-xl font-medium hover:shadow-glow transition-all"
        >
          <Download className="w-5 h-5" />
          <span>Export Report</span>
        </motion.button>
      </motion.div>

      {/* Tabs */}
      <div className="flex space-x-1 bg-light-glass dark:bg-dark-glass rounded-xl p-1">
        {tabs.map((tab) => (
          <motion.button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center space-x-2 px-4 py-3 rounded-lg transition-all ${
              activeTab === tab.id
                ? 'bg-lime-accent text-light-base dark:text-dark-base shadow-lg'
                : 'text-light-text dark:text-dark-text hover:bg-light-surface dark:hover:bg-dark-surface'
            }`}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <tab.icon className="w-5 h-5" />
            <span className="font-medium">{tab.label}</span>
          </motion.button>
        ))}
      </div>

      {/* Tab Content */}
      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Key Financial Metrics */}
            <div className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6">
              <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
                Key Financial Metrics
              </h3>
              <div className="space-y-4">
                {[
                  { label: 'Total Revenue', value: '$2.4M', change: '+12.5%', trend: 'up' },
                  { label: 'Net Income', value: '$437K', change: '+18.2%', trend: 'up' },
                  { label: 'Total Assets', value: '$3.8M', change: '+8.7%', trend: 'up' },
                  { label: 'Total Liabilities', value: '$1.2M', change: '+2.1%', trend: 'up' }
                ].map((metric, index) => (
                  <motion.div
                    key={metric.label}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="flex items-center justify-between p-4 bg-light-glass dark:bg-dark-glass rounded-lg"
                  >
                    <span className="text-light-text dark:text-dark-text">{metric.label}</span>
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-light-text dark:text-dark-text">{metric.value}</span>
                      <span className={`text-sm ${metric.trend === 'up' ? 'text-lime-accent' : 'text-red-400'}`}>
                        {metric.change}
                      </span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Cash Flow Chart */}
            <div className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6">
              <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
                Cash Flow Trend
              </h3>
              <div className="h-64 flex items-end space-x-2">
                {[45, 52, 48, 61, 58, 67, 72, 69, 75, 82, 78, 85].map((height, index) => (
                  <motion.div
                    key={index}
                    initial={{ height: 0 }}
                    animate={{ height: `${height}%` }}
                    transition={{ duration: 0.8, delay: index * 0.1 }}
                    className="flex-1 bg-gradient-to-t from-blue-400/20 to-blue-400/60 rounded-t-sm min-h-[20px]"
                  />
                ))}
              </div>
              <div className="flex justify-between mt-4 text-xs text-light-text-secondary dark:text-dark-text-secondary">
                {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map(month => (
                  <span key={month}>{month}</span>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'ratios' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {financialMetrics.map((category, categoryIndex) => (
              <motion.div
                key={category.category}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: categoryIndex * 0.1 }}
                className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6"
              >
                <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
                  {category.category}
                </h3>
                <div className="space-y-4">
                  {category.metrics.map((metric, index) => (
                    <motion.div
                      key={metric.name}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: categoryIndex * 0.1 + index * 0.05 }}
                      className="p-4 bg-light-glass dark:bg-dark-glass rounded-lg"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-light-text dark:text-dark-text">{metric.name}</span>
                        <div className={`flex items-center space-x-1 ${
                          metric.trend === 'up' ? 'text-lime-accent' : 'text-red-400'
                        }`}>
                          {metric.trend === 'up' ? (
                            <TrendingUp className="w-4 h-4" />
                          ) : (
                            <TrendingDown className="w-4 h-4" />
                          )}
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-bold text-light-text dark:text-dark-text">{metric.value}</span>
                        <span className={`text-sm ${metric.trend === 'up' ? 'text-lime-accent' : 'text-red-400'}`}>
                          {metric.change}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {activeTab === 'breakdown' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Revenue Breakdown */}
            <div className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6">
              <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
                Revenue Breakdown
              </h3>
              <div className="space-y-4">
                {revenueBreakdown.map((item, index) => (
                  <motion.div
                    key={item.category}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-light-text dark:text-dark-text">{item.category}</span>
                      <span className="font-bold text-light-text dark:text-dark-text">
                        ${item.amount.toLocaleString()}
                      </span>
                    </div>
                    <div className="w-full bg-light-glass dark:bg-dark-glass rounded-full h-2">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${item.percentage}%` }}
                        transition={{ duration: 1, delay: index * 0.1 + 0.3 }}
                        className={`h-2 ${item.color} rounded-full`}
                      />
                    </div>
                    <span className="text-sm text-light-text-secondary dark:text-dark-text-secondary">
                      {item.percentage}% of total revenue
                    </span>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Expense Breakdown */}
            <div className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6">
              <h3 className="text-xl font-bold text-light-text dark:text-dark-text font-editorial mb-6">
                Expense Breakdown
              </h3>
              <div className="space-y-4">
                {expenseBreakdown.map((item, index) => (
                  <motion.div
                    key={item.category}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-light-text dark:text-dark-text">{item.category}</span>
                      <span className="font-bold text-light-text dark:text-dark-text">
                        ${item.amount.toLocaleString()}
                      </span>
                    </div>
                    <div className="w-full bg-light-glass dark:bg-dark-glass rounded-full h-2">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${item.percentage}%` }}
                        transition={{ duration: 1, delay: index * 0.1 + 0.3 }}
                        className={`h-2 ${item.color} rounded-full`}
                      />
                    </div>
                    <span className="text-sm text-light-text-secondary dark:text-dark-text-secondary">
                      {item.percentage}% of total expenses
                    </span>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'statements' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {[
                { title: 'Income Statement', description: 'Revenue, expenses, and profit analysis' },
                { title: 'Balance Sheet', description: 'Assets, liabilities, and equity overview' },
                { title: 'Cash Flow Statement', description: 'Operating, investing, and financing activities' }
              ].map((statement, index) => (
                <motion.div
                  key={statement.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                  className="bg-light-surface/50 dark:bg-dark-surface/50 backdrop-blur-sm border border-light-border dark:border-dark-border rounded-xl p-6 cursor-pointer hover:border-lime-accent/30 transition-all"
                >
                  <FileText className="w-8 h-8 text-lime-accent mb-4" />
                  <h3 className="text-lg font-bold text-light-text dark:text-dark-text font-editorial mb-2">
                    {statement.title}
                  </h3>
                  <p className="text-light-text-secondary dark:text-dark-text-secondary text-sm">
                    {statement.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};