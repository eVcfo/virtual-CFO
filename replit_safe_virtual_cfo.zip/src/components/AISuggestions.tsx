import React, { useState } from 'react';
import axios from 'axios';

const AISuggestions = ({ insights }: { insights: any }) => {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const getSuggestions = async () => {
    setLoading(true);
    try {
      const response = await axios.post('/api/ai-suggestions', { insights });
      setSuggestions(response.data.suggestions);
    } catch (error) {
      console.error('AI suggestion error', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-6">
      <button
        onClick={getSuggestions}
        className="bg-purple-600 text-white px-4 py-2 rounded"
        disabled={loading}
      >
        {loading ? "Thinking..." : "Get Smart Suggestions"}
      </button>

      {suggestions.length > 0 && (
        <div className="mt-4 space-y-2">
          <h3 className="text-lg font-semibold">AI Suggestions:</h3>
          <ul className="list-disc list-inside">
            {suggestions.map((s, i) => <li key={i}>{s}</li>)}
          </ul>
        </div>
      )}
    </div>
  );
};

export default AISuggestions;