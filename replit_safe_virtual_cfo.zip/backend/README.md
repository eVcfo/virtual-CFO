# Financial Analytics Backend

A comprehensive backend system for financial and operational data analysis with advanced forecasting capabilities.

## Features

### 🔐 Security & Authentication
- JWT-based authentication with refresh tokens
- Role-based access control (Admin, Analyst, Viewer)
- Input validation and sanitization
- Rate limiting and DDoS protection
- Helmet.js security headers
- CORS configuration

### 📊 Data Processing
- Multi-format file upload support (CSV, Excel, JSON, XML)
- Automated data validation and sanitization
- Real-time data processing with progress tracking
- Data type conversion and formatting
- Error handling and reporting

### 💰 Financial Analysis
- Comprehensive financial ratio calculations
- Profitability, liquidity, efficiency, and leverage analysis
- Trend analysis with statistical methods
- Financial health assessment with scoring
- Revenue and expense breakdown analysis

### 📈 Forecasting Engine
- Multiple forecasting methods (Linear, Exponential, Seasonal)
- Automatic method selection based on data characteristics
- Confidence intervals and accuracy metrics
- Scenario analysis (Conservative, Optimistic, Pessimistic)
- Support for both financial and operational metrics

### 🏭 Operational Analytics
- Employee productivity tracking
- Production efficiency monitoring
- Customer satisfaction analysis
- Inventory management metrics
- Supply chain performance tracking

### 🚀 Performance & Scalability
- Redis caching for improved response times
- Database query optimization with proper indexing
- Connection pooling and resource management
- Efficient memory usage patterns
- Concurrent request handling

### 📝 Logging & Monitoring
- Comprehensive logging with Winston
- Request/response tracking
- Error monitoring and alerting
- Performance metrics collection
- Health check endpoints

## Installation

### Prerequisites
- Node.js 18+ 
- MongoDB 5.0+
- Redis 6.0+ (optional, for caching)

### Setup

1. **Clone and install dependencies:**
```bash
cd backend
npm install
```

2. **Environment Configuration:**
```bash
cp .env.example .env
# Edit .env with your configuration
```

3. **Database Setup:**
```bash
# Start MongoDB
mongod

# Start Redis (optional)
redis-server
```

4. **Build and Start:**
```bash
# Development
npm run dev

# Production
npm run build
npm start
```

## API Documentation

### Authentication Endpoints

#### Register User
```http
POST /api/auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "securepassword",
  "firstName": "John",
  "lastName": "Doe",
  "companyName": "Acme Corp",
  "role": "analyst"
}
```

#### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "securepassword"
}
```

### Data Management Endpoints

#### Upload Data File
```http
POST /api/data/upload
Authorization: Bearer <token>
Content-Type: multipart/form-data

file: <file>
dataType: financial|operational|hr|sales
period: daily|weekly|monthly|quarterly|yearly
```

#### Get Uploaded Files
```http
GET /api/data/files?dataType=financial&limit=50&offset=0
Authorization: Bearer <token>
```

### Financial Analysis Endpoints

#### Get Financial Analysis
```http
GET /api/financial/analysis?startDate=2024-01-01&endDate=2024-12-31&period=monthly
Authorization: Bearer <token>
```

#### Get Financial Trends
```http
GET /api/financial/trends?startDate=2024-01-01&endDate=2024-12-31&period=monthly
Authorization: Bearer <token>
```

#### Get Financial Health Assessment
```http
GET /api/financial/health?date=2024-12-31
Authorization: Bearer <token>
```

### Forecasting Endpoints

#### Generate Revenue Forecast
```http
POST /api/forecasting/revenue
Authorization: Bearer <token>
Content-Type: application/json

{
  "periods": 12,
  "method": "auto",
  "confidence": 0.95
}
```

#### Generate Operational Forecast
```http
POST /api/forecasting/operational
Authorization: Bearer <token>
Content-Type: application/json

{
  "metric": "employee_productivity",
  "periods": 6,
  "method": "linear"
}
```

## Data Models

### Financial Data Structure
```typescript
{
  companyId: ObjectId,
  date: Date,
  period: 'monthly',
  revenue: {
    total: number,
    recurring: number,
    oneTime: number,
    byProduct: Map<string, number>,
    byRegion: Map<string, number>
  },
  expenses: {
    total: number,
    operational: number,
    marketing: number,
    rd: number,
    administrative: number,
    other: number
  },
  profitability: {
    grossProfit: number,
    netProfit: number,
    ebitda: number,
    margins: {
      gross: number,
      net: number,
      ebitda: number
    }
  },
  ratios: {
    liquidity: { current: number, quick: number, cash: number },
    profitability: { roa: number, roe: number, roic: number },
    efficiency: { assetTurnover: number, inventoryTurnover: number },
    leverage: { debtToEquity: number, debtToAssets: number }
  }
}
```

### Operational Data Structure
```typescript
{
  companyId: ObjectId,
  date: Date,
  period: 'monthly',
  employees: {
    total: number,
    productivity: { overall: number, byDepartment: Map }
  },
  production: {
    output: number,
    capacity: number,
    efficiency: number,
    qualityScore: number
  },
  customers: {
    total: number,
    satisfactionScore: number,
    churnRate: number
  },
  inventory: {
    totalValue: number,
    turnoverRate: number
  }
}
```

## Business Logic Examples

### Financial Ratio Calculations
```typescript
// Current Ratio = Current Assets / Current Liabilities
const currentRatio = balanceSheet.assets.current / balanceSheet.liabilities.current;

// Return on Assets = Net Income / Total Assets
const roa = (revenue.total - expenses.total) / balanceSheet.assets.total * 100;

// Debt-to-Equity Ratio = Total Liabilities / Total Equity
const debtToEquity = balanceSheet.liabilities.total / balanceSheet.equity;
```

### Forecasting Algorithms
```typescript
// Linear Regression Forecast
const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
const intercept = (sumY - slope * sumX) / n;
const forecast = slope * futureX + intercept;

// Exponential Smoothing
const smoothed = alpha * currentValue + (1 - alpha) * previousSmoothed;

// Seasonal Decomposition
const seasonalIndex = monthlyAverage / overallAverage;
const forecastValue = trendValue * seasonalIndex;
```

## Performance Optimizations

### Database Indexing
```javascript
// Compound indexes for efficient queries
{ companyId: 1, date: -1 }
{ companyId: 1, period: 1, date: -1 }
{ companyId: 1, 'metadata.validated': 1, date: -1 }
```

### Caching Strategy
```typescript
// Cache financial trends for 1 hour
const cacheKey = `financial_trends:${companyId}:${period}:${startDate}:${endDate}`;
await redisClient.set(cacheKey, JSON.stringify(trends), 3600);
```

### Memory Management
- Connection pooling with MongoDB
- Streaming for large file processing
- Garbage collection optimization
- Resource cleanup in error handlers

## Security Measures

### Input Validation
```typescript
// Joi schema validation
const schema = Joi.object({
  revenue: Joi.number().min(0).required(),
  expenses: Joi.number().min(0).required(),
  date: Joi.date().iso().required()
});
```

### Authentication & Authorization
```typescript
// JWT middleware with role checking
const authMiddleware = async (req, res, next) => {
  const token = req.header('Authorization')?.replace('Bearer ', '');
  const decoded = jwt.verify(token, JWT_SECRET);
  req.user = await User.findById(decoded.id);
  next();
};
```

### Rate Limiting
```typescript
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP'
});
```

## Error Handling

### Custom Error Classes
```typescript
class AppError extends Error {
  constructor(message: string, statusCode: number, details?: any) {
    super(message);
    this.statusCode = statusCode;
    this.details = details;
  }
}
```

### Global Error Handler
```typescript
const errorHandler = (error, req, res, next) => {
  logger.error('Error occurred:', {
    message: error.message,
    stack: error.stack,
    path: req.path,
    method: req.method
  });
  
  res.status(error.statusCode || 500).json({
    success: false,
    message: error.message,
    ...(process.env.NODE_ENV === 'development' && { stack: error.stack })
  });
};
```

## Testing

```bash
# Run tests
npm test

# Run with coverage
npm run test:coverage

# Run specific test suite
npm test -- --grep "Financial Analysis"
```

## Deployment

### Docker Deployment
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3001
CMD ["npm", "start"]
```

### Environment Variables
- Set all required environment variables
- Use secrets management for sensitive data
- Configure proper logging levels
- Set up monitoring and alerting

## Contributing

1. Fork the repository
2. Create a feature branch
3. Write tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## License

MIT License - see LICENSE file for details