import xlsx from 'xlsx';

export async function parseFinancialExcel(filePath: string) {
  const workbook = xlsx.readFile(filePath);
  const getSheet = (name: string) => workbook.Sheets[name] || {};
  const sheetToJson = (sheet: any) => xlsx.utils.sheet_to_json(sheet, { defval: 0 });

  const pnl = sheetToJson(getSheet('Profit & Loss'));
  const bs = sheetToJson(getSheet('Balance Sheet'));
  const cf = sheetToJson(getSheet('Cash Flow'));
  const op = sheetToJson(getSheet('Operational Metrics'));

  const financialData = {
    pnl,
    balanceSheet: bs,
    cashFlow: cf
  };

  const operationalData = {
    metrics: op
  };

  return { financialData, operationalData };
}