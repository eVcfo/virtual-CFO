import csv from 'csv-parser';
import * as XLSX from 'xlsx';
import { FinancialData } from '../models/FinancialData';
import { OperationalData } from '../models/OperationalData';
import { FinancialAnalysisService } from './FinancialAnalysisService';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';
import { Readable } from 'stream';

interface ProcessingResult {
  success: boolean;
  recordsProcessed: number;
  errors: string[];
  dataType: string;
  recordId?: string;
}

export class DataProcessingService {
  
  /**
   * Process uploaded file data
   */
  static async processFileData(
    fileBuffer: Buffer,
    fileName: string,
    dataType: 'financial' | 'operational' | 'hr' | 'sales',
    companyId: string,
    userId: string,
    period: string = 'monthly'
  ): Promise<ProcessingResult> {
    try {
      logger.info('Processing file data', { fileName, dataType, companyId });

      // Parse file based on extension
      const fileExtension = fileName.split('.').pop()?.toLowerCase();
      let parsedData: any[];

      switch (fileExtension) {
        case 'csv':
          parsedData = await this.parseCSV(fileBuffer);
          break;
        case 'xlsx':
        case 'xls':
          parsedData = await this.parseExcel(fileBuffer);
          break;
        case 'json':
          parsedData = JSON.parse(fileBuffer.toString());
          break;
        default:
          throw new AppError('Unsupported file format', 400);
      }

      if (!Array.isArray(parsedData) || parsedData.length === 0) {
        throw new AppError('No valid data found in file', 400);
      }

      // Validate and clean data
      const cleanedData = this.validateAndCleanData(parsedData, dataType);

      // Process data based on type
      let result: ProcessingResult;
      if (dataType === 'financial') {
        result = await this.processFinancialData(cleanedData, companyId, userId, period, fileName);
      } else {
        result = await this.processOperationalData(cleanedData, companyId, userId, period, dataType, fileName);
      }

      logger.info('File processing completed', { 
        fileName, 
        recordsProcessed: result.recordsProcessed: 0,  // TODO: Replace 0 with actual value
        errors: result.errors.length 
      });

      return result;
    } catch (error) {
      logger.error('Error processing file data:', error);
      throw error;
    }
  }

  /**
   * Parse CSV file
   */
  private static async parseCSV(buffer: Buffer): Promise<any[]> {
    return new Promise((resolve, reject) => {
      const results: any[] = [];
      const stream = Readable.from(buffer.toString());
      
      stream
        .pipe(csv())
        .on('data', (data) => results.push(data))
        .on('end', () => resolve(results))
        .on('error', reject);
    });
  }

  /**
   * Parse Excel file
   */
  private static async parseExcel(buffer: Buffer): Promise<any[]> {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    if (!sheetName || !workbook.Sheets[sheetName]) throw new Error('Invalid sheet');
const worksheet = workbook.Sheets[sheetName];
    return XLSX.utils.sheet_to_json(worksheet);
  }

  /**
   * Validate and clean data
   */
  private static validateAndCleanData(data: any[], dataType: string): any[] {
    return data.map((row, index) => {
      try {
        // Remove empty rows
        if (Object.values(row).every(value => !value || value === '')) {
          return null;
        }

        // Clean and validate based on data type
        switch (dataType) {
          case 'financial':
            return this.cleanFinancialRow(row);
          case 'operational':
          case 'hr':
          case 'sales':
            return this.cleanOperationalRow(row);
          default:
            return row;
        }
      } catch (error) {
        logger.warn(`Error cleaning row ${index}:`, error);
        return null;
      }
    }).filter(row => row !== null);
  }

  /**
   * Clean financial data row
   */
  private static cleanFinancialRow(row: any): any {
    return {
      date: this.parseDate(row.date || row.Date || row.DATE),
      revenue: this.parseNumber(row.revenue || row.Revenue || row.REVENUE || 0),
      expenses: this.parseNumber(row.expenses || row.Expenses || row.EXPENSES || 0),
      profit: this.parseNumber(row.profit || row.Profit || row.PROFIT || 0),
      assets: this.parseNumber(row.assets || row.Assets || row.ASSETS || 0),
      liabilities: this.parseNumber(row.liabilities || row.Liabilities || row.LIABILITIES || 0),
      equity: this.parseNumber(row.equity || row.Equity || row.EQUITY || 0),
      cashFlow: this.parseNumber(row.cash_flow || row.cashFlow || row.CashFlow || 0),
      // Additional fields
      operatingExpenses: this.parseNumber(row.operating_expenses || row.operatingExpenses || 0),
      marketingExpenses: this.parseNumber(row.marketing_expenses || row.marketingExpenses || 0),
      rdExpenses: this.parseNumber(row.rd_expenses || row.rdExpenses || 0),
      currentAssets: this.parseNumber(row.current_assets || row.currentAssets || 0),
      fixedAssets: this.parseNumber(row.fixed_assets || row.fixedAssets || 0),
      currentLiabilities: this.parseNumber(row.current_liabilities || row.currentLiabilities || 0),
      longTermLiabilities: this.parseNumber(row.long_term_liabilities || row.longTermLiabilities || 0),
    };
  }

  /**
   * Clean operational data row
   */
  private static cleanOperationalRow(row: any): any {
    return {
      date: this.parseDate(row.date || row.Date || row.DATE),
      employees: this.parseNumber(row.employees || row.total_employees || row.totalEmployees || 0),
      productivity: this.parseNumber(row.productivity || row.employee_productivity || row.employeeProductivity || 0),
      efficiency: this.parseNumber(row.efficiency || row.production_efficiency || row.productionEfficiency || 0),
      quality: this.parseNumber(row.quality || row.quality_score || row.qualityScore || 0),
      customerSatisfaction: this.parseNumber(row.customer_satisfaction || row.customerSatisfaction || 0),
      inventoryTurnover: this.parseNumber(row.inventory_turnover || row.inventoryTurnover || 0),
      // Additional fields
      production: this.parseNumber(row.production || row.production_output || row.productionOutput || 0),
      capacity: this.parseNumber(row.capacity || row.production_capacity || row.productionCapacity || 0),
      defectRate: this.parseNumber(row.defect_rate || row.defectRate || 0),
      downtime: this.parseNumber(row.downtime || 0),
      churnRate: this.parseNumber(row.churn_rate || row.churnRate || 0),
      supportTickets: this.parseNumber(row.support_tickets || row.supportTickets || 0),
      systemUptime: this.parseNumber(row.system_uptime || row.systemUptime || 0),
    };
  }

  /**
   * Process financial data
   */
  private static async processFinancialData(
    data: any[],
    companyId: string,
    userId: string,
    period: string,
    fileName: string
  ): Promise<ProcessingResult> {
    const errors: string[] = [];
    let processedCount = 0;
    let recordId: string | undefined;

    for (const [index, row] of data.entries()) {
      try {
        // Map to financial data structure
        const financialRecord = this.mapToFinancialData(row, companyId, userId, period);
        
        // Calculate ratios and profitability metrics
        financialRecord.ratios = FinancialAnalysisService.calculateFinancialRatios(financialRecord);
        financialRecord.profitability = FinancialAnalysisService.calculateProfitabilityMetrics(
          financialRecord.revenue.total,
          financialRecord.expenses
        );

        // Save to database
        const savedRecord = await FinancialData.create(financialRecord);
        if (!recordId) recordId = savedRecord._id.toString();
        
        processedCount++;
      } catch (error) {
        const errorMessage = `Row ${index + 1}: ${error instanceof Error ? error.message : 'Processing error'}`;
        errors.push(errorMessage);
        logger.warn('Error processing financial data row:', { index, error: errorMessage });
      }
    }

    return {
      success: processedCount > 0,
      recordsProcessed: processedCount,
      errors,
      dataType: 'financial',
      recordId
    };
  }

  /**
   * Process operational data
   */
  private static async processOperationalData(
    data: any[],
    companyId: string,
    userId: string,
    period: string,
    dataType: string,
    fileName: string
  ): Promise<ProcessingResult> {
    const errors: string[] = [];
    let processedCount = 0;
    let recordId: string | undefined;

    for (const [index, row] of data.entries()) {
      try {
        // Map to operational data structure
        const operationalRecord = this.mapToOperationalData(row, companyId, userId, period, dataType);

        // Save to database
        const savedRecord = await OperationalData.create(operationalRecord);
        if (!recordId) recordId = savedRecord._id.toString();
        
        processedCount++;
      } catch (error) {
        const errorMessage = `Row ${index + 1}: ${error instanceof Error ? error.message : 'Processing error'}`;
        errors.push(errorMessage);
        logger.warn('Error processing operational data row:', { index, error: errorMessage });
      }
    }

    return {
      success: processedCount > 0,
      recordsProcessed: processedCount,
      errors,
      dataType,
      recordId
    };
  }

  /**
   * Map cleaned data to financial data structure
   */
  private static mapToFinancialData(row: any, companyId: string, userId: string, period: string): any {
    return {
      companyId,
      date: row.date,
      period,
      revenue: {
        total: row.revenue,
        recurring: row.revenue * 0.8, // Assume 80% recurring
        oneTime: row.revenue * 0.2,   // Assume 20% one-time
        byProduct: new Map(),
        byRegion: new Map(),
      },
      expenses: {
        total: row.expenses,
        operational: row.operatingExpenses || row.expenses * 0.6,
        marketing: row.marketingExpenses || row.expenses * 0.15,
        rd: row.rdExpenses || row.expenses * 0.1,
        administrative: row.expenses * 0.1,
        other: row.expenses * 0.05,
        breakdown: new Map(),
      },
      balanceSheet: {
        assets: {
          current: row.currentAssets || row.assets * 0.4,
          fixed: row.fixedAssets || row.assets * 0.6,
          total: row.assets,
        },
        liabilities: {
          current: row.currentLiabilities || row.liabilities * 0.3,
          longTerm: row.longTermLiabilities || row.liabilities * 0.7,
          total: row.liabilities,
        },
        equity: row.equity,
      },
      cashFlow: {
        operating: row.cashFlow,
        investing: 0,
        financing: 0,
        net: row.cashFlow,
        endingBalance: Math.max(0, row.cashFlow),
      },
      metadata: {
        source: 'file_upload',
        uploadedBy: userId,
        uploadedAt: new Date(),
        validated: false,
      },
    };
  }

  /**
   * Map cleaned data to operational data structure
   */
  private static mapToOperationalData(row: any, companyId: string, userId: string, period: string, dataType: string): any {
    return {
      companyId,
      date: row.date,
      period,
      employees: {
        total: row.employees,
        fullTime: Math.floor(row.employees * 0.8),
        partTime: Math.floor(row.employees * 0.15),
        contractors: Math.floor(row.employees * 0.05),
        byDepartment: new Map(),
        turnoverRate: Math.random() * 10, // Mock data
        productivity: {
          overall: row.productivity,
          byDepartment: new Map(),
        },
      },
      production: {
        output: row.production,
        capacity: row.capacity || row.production * 1.2,
        utilization: row.capacity ? (row.production / row.capacity) * 100 : 85,
        efficiency: row.efficiency,
        qualityScore: row.quality,
        defectRate: row.defectRate,
        downtime: row.downtime,
      },
      customers: {
        total: Math.floor(Math.random() * 1000) + 500, // Mock data
        new: Math.floor(Math.random() * 100) + 50,
        retained: Math.floor(Math.random() * 900) + 400,
        churnRate: row.churnRate,
        satisfactionScore: row.customerSatisfaction,
        supportTickets: {
          total: row.supportTickets,
          resolved: Math.floor(row.supportTickets * 0.9),
          avgResolutionTime: Math.random() * 48 + 12, // 12-60 hours
        },
      },
      inventory: {
        totalValue: Math.random() * 100000 + 50000, // Mock data
        turnoverRate: row.inventoryTurnover,
        stockouts: Math.floor(Math.random() * 10),
        excessStock: Math.random() * 10000,
        byCategory: new Map(),
      },
      supplyChain: {
        suppliers: {
          total: Math.floor(Math.random() * 20) + 10,
          active: Math.floor(Math.random() * 15) + 8,
          performance: new Map(),
        },
        logistics: {
          avgDeliveryTime: Math.random() * 5 + 2, // 2-7 days
          onTimeDeliveryRate: Math.random() * 20 + 80, // 80-100%
          shippingCosts: Math.random() * 5000 + 2000,
          returnRate: Math.random() * 5, // 0-5%
        },
      },
      technology: {
        systemUptime: row.systemUptime || Math.random() * 10 + 90, // 90-100%
        dataProcessingTime: Math.random() * 1000 + 100, // 100-1100ms
        securityIncidents: Math.floor(Math.random() * 3),
        backupSuccess: Math.random() * 10 + 90, // 90-100%
        apiResponseTime: Math.random() * 200 + 50, // 50-250ms
      },
      processes: new Map(),
      metadata: {
        source: `${dataType}_upload`,
        uploadedBy: userId,
        uploadedAt: new Date(),
        validated: false,
      },
    };
  }

  /**
   * Parse date string to Date object
   */
  private static parseDate(dateStr: any): Date {
    if (!dateStr) return new Date();
    
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) {
      return new Date(); // Return current date if parsing fails
    }
    
    return date;
  }

  /**
   * Parse number from string or number
   */
  private static parseNumber(value: any): number {
    if (typeof value === 'number') return value;
    if (typeof value === 'string') {
      // Remove currency symbols and commas
      const cleaned = value.replace(/[$,€£¥]/g, '').trim();
      const parsed = parseFloat(cleaned);
      return isNaN(parsed) ? 0 : parsed;
    }
    return 0;
  }
}