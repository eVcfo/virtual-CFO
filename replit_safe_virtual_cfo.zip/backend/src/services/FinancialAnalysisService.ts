import { FinancialData, IFinancialData } from '../models/FinancialData';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';
import { redisClient } from '../config/redis';

export class FinancialAnalysisService {
  
  /**
   * Calculate financial ratios from raw data
   */
  static calculateFinancialRatios(data: Partial<IFinancialData>): IFinancialData['ratios'] {
    const { revenue, expenses, balanceSheet, cashFlow } = data;
    
    if (!revenue || !expenses || !balanceSheet) {
      throw new AppError('Insufficient data for ratio calculations', 400);
    }

    const ratios: IFinancialData['ratios'] = {
      liquidity: {
        current: balanceSheet.assets.current / balanceSheet.liabilities.current || 0,
        quick: (balanceSheet.assets.current - (balanceSheet.assets.current * 0.3)) / balanceSheet.liabilities.current || 0,
        cash: cashFlow?.endingBalance / balanceSheet.liabilities.current || 0,
      },
      profitability: {
        roa: ((revenue.total - expenses.total) / balanceSheet.assets.total) * 100 || 0,
        roe: ((revenue.total - expenses.total) / balanceSheet.equity) * 100 || 0,
        roic: ((revenue.total - expenses.total) / (balanceSheet.equity + balanceSheet.liabilities.longTerm)) * 100 || 0,
      },
      efficiency: {
        assetTurnover: revenue.total / balanceSheet.assets.total || 0,
        inventoryTurnover: expenses.total / (balanceSheet.assets.current * 0.4) || 0, // Assuming 40% of current assets is inventory
        receivablesTurnover: revenue.total / (balanceSheet.assets.current * 0.3) || 0, // Assuming 30% of current assets is receivables
      },
      leverage: {
        debtToEquity: balanceSheet.liabilities.total / balanceSheet.equity || 0,
        debtToAssets: balanceSheet.liabilities.total / balanceSheet.assets.total || 0,
        interestCoverage: (revenue.total - expenses.operational) / (expenses.total * 0.05) || 0, // Assuming 5% of expenses is interest
      },
    };

    return ratios;
  }

  /**
   * Calculate profitability metrics
   */
  static calculateProfitabilityMetrics(revenue: number, expenses: IFinancialData['expenses']): IFinancialData['profitability'] {
    const grossProfit = revenue - expenses.operational;
    const netProfit = revenue - expenses.total;
    const ebitda = netProfit + (expenses.total * 0.1); // Simplified EBITDA calculation

    return {
      grossProfit,
      netProfit,
      ebitda,
      margins: {
        gross: (grossProfit / revenue) * 100,
        net: (netProfit / revenue) * 100,
        ebitda: (ebitda / revenue) * 100,
      },
    };
  }

  /**
   * Get financial trends over time
   */
  static async getFinancialTrends(
    companyId: string,
    startDate: Date,
    endDate: Date,
    period: 'monthly' | 'quarterly' | 'yearly' = 'monthly'
  ) {
    try {
      const cacheKey = `financial_trends:${companyId}:${period}:${startDate.toISOString()}:${endDate.toISOString()}`;
      
      // Check cache first
      const cachedData = await redisClient.get(cacheKey);
      if (cachedData) {
        return JSON.parse(cachedData);
      }

      const data = await FinancialData.find({
        companyId,
        date: { $gte: startDate, $lte: endDate },
        period,
        'metadata.validated': true,
      })
      .sort({ date: 1 })
      .lean();

      if (data.length === 0) {
        throw new AppError('No financial data found for the specified period', 404);
      }

      // Calculate trends
      const trends = {
        revenue: this.calculateTrend(data.map(d => ({ date: d.date, value: d.revenue.total }))),
        profit: this.calculateTrend(data.map(d => ({ date: d.date, value: d.profitability.netProfit }))),
        expenses: this.calculateTrend(data.map(d => ({ date: d.date, value: d.expenses.total }))),
        margins: {
          gross: this.calculateTrend(data.map(d => ({ date: d.date, value: d.profitability.margins.gross }))),
          net: this.calculateTrend(data.map(d => ({ date: d.date, value: d.profitability.margins.net }))),
        },
        ratios: {
          current: this.calculateTrend(data.map(d => ({ date: d.date, value: d.ratios.liquidity.current }))),
          roa: this.calculateTrend(data.map(d => ({ date: d.date, value: d.ratios.profitability.roa }))),
          debtToEquity: this.calculateTrend(data.map(d => ({ date: d.date, value: d.ratios.leverage.debtToEquity }))),
        },
      };

      // Cache for 1 hour
      await redisClient.set(cacheKey, JSON.stringify(trends), 3600);

      return trends;
    } catch (error) {
      logger.error('Error calculating financial trends:', error);
      throw error;
    }
  }

  /**
   * Calculate trend analysis for a series of data points
   */
  private static calculateTrend(data: { date: Date; value: number }[]) {
    if (data.length < 2) {
      return { slope: 0, direction: 'stable', changePercent: 0, correlation: 0 };
    }

    // Sort by date
    data.sort((a, b) => a.date.getTime() - b.date.getTime());

    // Calculate linear regression
    const n = data.length;
    const sumX = data.reduce((sum, _, i) => sum + i, 0);
    const sumY = data.reduce((sum, d) => sum + d.value, 0);
    const sumXY = data.reduce((sum, d, i) => sum + i * d.value, 0);
    const sumXX = data.reduce((sum, _, i) => sum + i * i, 0);

    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    
    // Calculate correlation coefficient
    const meanX = sumX / n;
    const meanY = sumY / n;
    const numerator = data.reduce((sum, d, i) => sum + (i - meanX) * (d.value - meanY), 0);
    const denomX = Math.sqrt(data.reduce((sum, _, i) => sum + Math.pow(i - meanX, 2), 0));
    const denomY = Math.sqrt(data.reduce((sum, d) => sum + Math.pow(d.value - meanY, 2), 0));
    const correlation = numerator / (denomX * denomY) || 0;

    // Calculate percentage change
    const firstValue = data?.[0]?.value ?? 0;
    const lastValue = data?.[data.length - 1]?.value ?? 0;
    const changePercent = firstValue !== 0 ? ((lastValue - firstValue) / firstValue) * 100 : 0;

    // Determine direction
    let direction: 'increasing' | 'decreasing' | 'stable';
    if (Math.abs(slope) < 0.01) {
      direction = 'stable';
    } else if (slope > 0) {
      direction = 'increasing';
    } else {
      direction = 'decreasing';
    }

    return {
      slope,
      direction,
      changePercent,
      correlation,
      dataPoints: data.length,
    };
  }

  /**
   * Perform financial health assessment
   */
  static async assessFinancialHealth(companyId: string, date?: Date) {
    try {
      const targetDate = date || new Date();
      
      // Get the most recent financial data
      const latestData = await FinancialData.findOne({
        companyId,
        date: { $lte: targetDate },
        'metadata.validated': true,
      })
      .sort({ date: -1 })
      .lean();

      if (!latestData) {
        throw new AppError('No financial data available for assessment', 404);
      }

      const assessment = {
        overallScore: 0,
        categories: {
          liquidity: this.assessLiquidity(latestData.ratios.liquidity),
          profitability: this.assessProfitability(latestData.ratios.profitability),
          efficiency: this.assessEfficiency(latestData.ratios.efficiency),
          leverage: this.assessLeverage(latestData.ratios.leverage),
        },
        recommendations: [] as string[],
        riskFactors: [] as string[],
        strengths: [] as string[],
      };

      // Calculate overall score (weighted average)
      assessment.overallScore = (
        assessment.categories.liquidity.score * 0.25 +
        assessment.categories.profitability.score * 0.35 +
        assessment.categories.efficiency.score * 0.25 +
        assessment.categories.leverage.score * 0.15
      );

      // Generate recommendations based on weak areas
      Object.entries(assessment.categories).forEach(([category, result]) => {
        if (result.score < 60) {
          assessment.recommendations.push(...result.recommendations);
          assessment.riskFactors.push(...result.risks);
        } else if (result.score > 80) {
          assessment.strengths.push(...result.strengths);
        }
      });

      return assessment;
    } catch (error) {
      logger.error('Error assessing financial health:', error);
      throw error;
    }
  }

  /**
   * Assess liquidity ratios
   */
  private static assessLiquidity(ratios: IFinancialData['ratios']['liquidity']) {
    let score = 0;
    const recommendations: string[] = [];
    const risks: string[] = [];
    const strengths: string[] = [];

    // Current ratio assessment
    if (ratios.current >= 2) {
      score += 35;
      strengths.push('Strong current ratio indicates good short-term liquidity');
    } else if (ratios.current >= 1.5) {
      score += 25;
    } else if (ratios.current >= 1) {
      score += 15;
      recommendations.push('Consider improving current ratio by reducing current liabilities or increasing current assets');
    } else {
      score += 0;
      risks.push('Current ratio below 1 indicates potential liquidity problems');
      recommendations.push('Urgent: Address liquidity issues by securing additional funding or reducing short-term obligations');
    }

    // Quick ratio assessment
    if (ratios.quick >= 1.5) {
      score += 35;
      strengths.push('Excellent quick ratio shows strong immediate liquidity');
    } else if (ratios.quick >= 1) {
      score += 25;
    } else if (ratios.quick >= 0.8) {
      score += 15;
    } else {
      score += 0;
      risks.push('Low quick ratio may indicate difficulty meeting immediate obligations');
    }

    // Cash ratio assessment
    if (ratios.cash >= 0.5) {
      score += 30;
      strengths.push('High cash ratio provides excellent financial flexibility');
    } else if (ratios.cash >= 0.2) {
      score += 20;
    } else {
      score += 10;
      recommendations.push('Consider maintaining higher cash reserves for better financial flexibility');
    }

    return {
      score: Math.min(score, 100),
      recommendations,
      risks,
      strengths,
    };
  }

  /**
   * Assess profitability ratios
   */
  private static assessProfitability(ratios: IFinancialData['ratios']['profitability']) {
    let score = 0;
    const recommendations: string[] = [];
    const risks: string[] = [];
    const strengths: string[] = [];

    // ROA assessment
    if (ratios.roa >= 15) {
      score += 35;
      strengths.push('Excellent return on assets indicates efficient asset utilization');
    } else if (ratios.roa >= 10) {
      score += 25;
    } else if (ratios.roa >= 5) {
      score += 15;
    } else if (ratios.roa >= 0) {
      score += 5;
      recommendations.push('Focus on improving asset efficiency to increase ROA');
    } else {
      score += 0;
      risks.push('Negative ROA indicates poor asset utilization');
    }

    // ROE assessment
    if (ratios.roe >= 20) {
      score += 35;
      strengths.push('Outstanding return on equity shows strong shareholder value creation');
    } else if (ratios.roe >= 15) {
      score += 25;
    } else if (ratios.roe >= 10) {
      score += 15;
    } else if (ratios.roe >= 0) {
      score += 5;
      recommendations.push('Work on improving profitability to enhance shareholder returns');
    } else {
      score += 0;
      risks.push('Negative ROE indicates losses and poor shareholder value');
    }

    // ROIC assessment
    if (ratios.roic >= 15) {
      score += 30;
      strengths.push('Strong ROIC demonstrates effective capital allocation');
    } else if (ratios.roic >= 10) {
      score += 20;
    } else if (ratios.roic >= 5) {
      score += 10;
    } else {
      score += 0;
      recommendations.push('Improve capital allocation efficiency to increase ROIC');
    }

    return {
      score: Math.min(score, 100),
      recommendations,
      risks,
      strengths,
    };
  }

  /**
   * Assess efficiency ratios
   */
  private static assessEfficiency(ratios: IFinancialData['ratios']['efficiency']) {
    let score = 0;
    const recommendations: string[] = [];
    const risks: string[] = [];
    const strengths: string[] = [];

    // Asset turnover assessment
    if (ratios.assetTurnover >= 2) {
      score += 35;
      strengths.push('High asset turnover indicates excellent asset utilization');
    } else if (ratios.assetTurnover >= 1.5) {
      score += 25;
    } else if (ratios.assetTurnover >= 1) {
      score += 15;
    } else {
      score += 5;
      recommendations.push('Improve asset utilization to increase revenue generation');
    }

    // Inventory turnover assessment
    if (ratios.inventoryTurnover >= 12) {
      score += 35;
      strengths.push('Excellent inventory management with high turnover rate');
    } else if (ratios.inventoryTurnover >= 8) {
      score += 25;
    } else if (ratios.inventoryTurnover >= 4) {
      score += 15;
    } else {
      score += 5;
      recommendations.push('Optimize inventory management to reduce carrying costs');
    }

    // Receivables turnover assessment
    if (ratios.receivablesTurnover >= 12) {
      score += 30;
      strengths.push('Efficient collection processes with high receivables turnover');
    } else if (ratios.receivablesTurnover >= 8) {
      score += 20;
    } else if (ratios.receivablesTurnover >= 6) {
      score += 10;
    } else {
      score += 0;
      recommendations.push('Improve collection processes to reduce outstanding receivables');
      risks.push('Low receivables turnover may indicate collection issues');
    }

    return {
      score: Math.min(score, 100),
      recommendations,
      risks,
      strengths,
    };
  }

  /**
   * Assess leverage ratios
   */
  private static assessLeverage(ratios: IFinancialData['ratios']['leverage']) {
    let score = 0;
    const recommendations: string[] = [];
    const risks: string[] = [];
    const strengths: string[] = [];

    // Debt-to-equity assessment (lower is better)
    if (ratios.debtToEquity <= 0.3) {
      score += 40;
      strengths.push('Conservative debt levels provide financial stability');
    } else if (ratios.debtToEquity <= 0.6) {
      score += 30;
    } else if (ratios.debtToEquity <= 1) {
      score += 20;
      recommendations.push('Consider reducing debt levels to improve financial stability');
    } else if (ratios.debtToEquity <= 2) {
      score += 10;
      risks.push('High debt-to-equity ratio increases financial risk');
    } else {
      score += 0;
      risks.push('Very high debt levels pose significant financial risk');
      recommendations.push('Urgent: Develop debt reduction strategy');
    }

    // Debt-to-assets assessment (lower is better)
    if (ratios.debtToAssets <= 0.3) {
      score += 30;
      strengths.push('Low debt-to-assets ratio indicates strong financial position');
    } else if (ratios.debtToAssets <= 0.5) {
      score += 20;
    } else if (ratios.debtToAssets <= 0.7) {
      score += 10;
    } else {
      score += 0;
      risks.push('High debt-to-assets ratio limits financial flexibility');
    }

    // Interest coverage assessment
    if (ratios.interestCoverage >= 10) {
      score += 30;
      strengths.push('Excellent interest coverage provides debt service security');
    } else if (ratios.interestCoverage >= 5) {
      score += 20;
    } else if (ratios.interestCoverage >= 2.5) {
      score += 10;
    } else if (ratios.interestCoverage >= 1.5) {
      score += 5;
      recommendations.push('Improve earnings to strengthen interest coverage');
    } else {
      score += 0;
      risks.push('Low interest coverage indicates potential debt service difficulties');
      recommendations.push('Urgent: Address interest coverage issues');
    }

    return {
      score: Math.min(score, 100),
      recommendations,
      risks,
      strengths,
    };
  }

  /**
   * Generate financial summary report
   */
  static async generateFinancialSummary(companyId: string, startDate: Date, endDate: Date) {
    try {
      const data = await FinancialData.find({
        companyId,
        date: { $gte: startDate, $lte: endDate },
        'metadata.validated': true,
      })
      .sort({ date: -1 })
      .lean();

      if (data.length === 0) {
        throw new AppError('No financial data found for the specified period', 404);
      }

      const latestData = data[0];
      const previousData = data[1];

      // Calculate period totals
      const periodTotals = {
        revenue: data.reduce((sum, d) => sum + d.revenue.total, 0),
        expenses: data.reduce((sum, d) => sum + d.expenses.total, 0),
        netProfit: data.reduce((sum, d) => sum + d.profitability.netProfit, 0),
        cashFlow: data.reduce((sum, d) => sum + d.cashFlow.net, 0),
      };

      // Calculate changes from previous period
      const changes = previousData ? {
        revenue: ((latestData.revenue.total - previousData.revenue.total) / previousData.revenue.total) * 100,
        expenses: ((latestData.expenses.total - previousData.expenses.total) / previousData.expenses.total) * 100,
        netProfit: ((latestData.profitability.netProfit - previousData.profitability.netProfit) / Math.abs(previousData.profitability.netProfit)) * 100,
        margins: {
          gross: latestData.profitability.margins.gross - previousData.profitability.margins.gross,
          net: latestData.profitability.margins.net - previousData.profitability.margins.net,
        },
      } : null;

      return {
        period: {
          startDate,
          endDate,
          dataPoints: data.length,
        },
        current: {
          revenue: latestData.revenue.total,
          expenses: latestData.expenses.total,
          netProfit: latestData.profitability.netProfit,
          margins: latestData.profitability.margins,
          ratios: latestData.ratios,
          cashFlow: latestData.cashFlow,
          balanceSheet: latestData.balanceSheet,
        },
        periodTotals,
        changes,
        trends: await this.getFinancialTrends(companyId, startDate, endDate),
        healthAssessment: await this.assessFinancialHealth(companyId, latestData.date),
      };
    } catch (error) {
      logger.error('Error generating financial summary:', error);
      throw error;
    }
  }
}