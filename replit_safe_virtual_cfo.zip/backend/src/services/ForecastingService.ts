import { FinancialData } from '../models/FinancialData';
import { OperationalData } from '../models/OperationalData';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';
import { redisClient } from '../config/redis';

interface ForecastPoint {
  date: Date;
  value: number;
  confidence?: number;
}

interface ForecastResult {
  historical: ForecastPoint[];
  forecast: ForecastPoint[];
  method: string;
  accuracy: {
    mape: number; // Mean Absolute Percentage Error
    rmse: number; // Root Mean Square Error
    r2: number;   // R-squared
  };
  scenarios: {
    conservative: ForecastPoint[];
    optimistic: ForecastPoint[];
    pessimistic: ForecastPoint[];
  };
}

export class ForecastingService {
  
  /**
   * Generate revenue forecast using multiple methods
   */
  static async forecastRevenue(
    companyId: string,
    periods: number,
    method: 'linear' | 'exponential' | 'seasonal' | 'auto' = 'auto',
    confidence: number = 0.95
  ): Promise<ForecastResult> {
    try {
      const cacheKey = `forecast_revenue:${companyId}:${periods}:${method}:${confidence}`;
      
      // Check cache first
      const cachedData = await redisClient.get(cacheKey);
      if (cachedData) {
        return JSON.parse(cachedData);
      }

      // Get historical data (last 24 months for better accuracy)
      const historicalData = await FinancialData.find({
        companyId,
        period: 'monthly',
        'metadata.validated': true,
      })
      .sort({ date: -1 })
      .limit(24)
      .lean();

      if (historicalData.length < 6) {
        throw new AppError('Insufficient historical data for forecasting (minimum 6 months required)', 400);
      }

      // Reverse to chronological order
      historicalData.reverse();

      const historical: ForecastPoint[] = historicalData.map(d => ({
        date: d.date,
        value: d.revenue.total,
      }));

      // Determine best method if auto
      const selectedMethod = method === 'auto' ? this.selectBestMethod(historical) : method;

      // Generate forecast based on selected method
      let forecast: ForecastPoint[];
      switch (selectedMethod) {
        case 'linear':
          forecast = this.linearForecast(historical, periods);
          break;
        case 'exponential':
          forecast = this.exponentialForecast(historical, periods);
          break;
        case 'seasonal':
          forecast = this.seasonalForecast(historical, periods);
          break;
        default:
          forecast = this.linearForecast(historical, periods);
      }

      // Add confidence intervals
      forecast = this.addConfidenceIntervals(forecast, historical, confidence);

      // Calculate accuracy metrics
      const accuracy = this.calculateAccuracy(historical, selectedMethod);

      // Generate scenarios
      const scenarios = this.generateScenarios(forecast, historical);

      const result: ForecastResult = {
        historical,
        forecast,
        method: selectedMethod,
        accuracy,
        scenarios,
      };

      // Cache for 6 hours
      await redisClient.set(cacheKey, JSON.stringify(result), 21600);

      return result;
    } catch (error) {
      logger.error('Error forecasting revenue:', error);
      throw error;
    }
  }

  /**
   * Linear regression forecast
   */
  private static linearForecast(historical: ForecastPoint[], periods: number): ForecastPoint[] {
    const n = historical.length;
    const x = historical.map((_, i) => i);
    const y = historical.map(d => d.value);

    // Calculate linear regression coefficients
    const sumX = x.reduce((a, b) => a + b, 0);
    const sumY = y.reduce((a, b) => a + b, 0);
    const sumXY = x.reduce((sum, xi, i) => sum + xi * y[i], 0);
    const sumXX = x.reduce((sum, xi) => sum + xi * xi, 0);

    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;

    // Generate forecast points
    const forecast: ForecastPoint[] = [];
    const lastDate = historical[historical.length - 1].date;

    for (let i = 1; i <= periods; i++) {
      const futureDate = new Date(lastDate);
      futureDate.setMonth(futureDate.getMonth() + i);
      
      const predictedValue = slope * (n + i - 1) + intercept;
      
      forecast.push({
        date: futureDate,
        value: Math.max(0, predictedValue), // Ensure non-negative values
      });
    }

    return forecast;
  }

  /**
   * Exponential smoothing forecast
   */
  private static exponentialForecast(historical: ForecastPoint[], periods: number): ForecastPoint[] {
    const alpha = 0.3; // Smoothing parameter
    const values = historical.map(d => d.value);
    
    // Calculate exponential smoothing
    let smoothed = values[0];
    const smoothedValues = [smoothed];

    for (let i = 1; i < values.length; i++) {
      smoothed = alpha * values[i] + (1 - alpha) * smoothed;
      smoothedValues.push(smoothed);
    }

    // Calculate trend
    const trend = this.calculateTrend(smoothedValues);

    // Generate forecast
    const forecast: ForecastPoint[] = [];
    const lastDate = historical[historical.length - 1].date;
    let lastValue = smoothedValues[smoothedValues.length - 1];

    for (let i = 1; i <= periods; i++) {
      const futureDate = new Date(lastDate);
      futureDate.setMonth(futureDate.getMonth() + i);
      
      lastValue = lastValue * (1 + trend);
      
      forecast.push({
        date: futureDate,
        value: Math.max(0, lastValue),
      });
    }

    return forecast;
  }

  /**
   * Seasonal decomposition forecast
   */
  private static seasonalForecast(historical: ForecastPoint[], periods: number): ForecastPoint[] {
    if (historical.length < 12) {
      // Fall back to linear if insufficient data for seasonal analysis
      return this.linearForecast(historical, periods);
    }

    const values = historical.map(d => d.value);
    
    // Calculate seasonal indices (assuming monthly data)
    const seasonalIndices = this.calculateSeasonalIndices(values);
    
    // Deseasonalize data
    const deseasonalized = values.map((value, i) => value / seasonalIndices[i % 12]);
    
    // Apply linear trend to deseasonalized data
    const trendForecast = this.linearForecast(
      deseasonalized.map((value, i) => ({
        date: historical[i].date,
        value,
      })),
      periods
    );

    // Reapply seasonal pattern
    const forecast: ForecastPoint[] = trendForecast.map((point, i) => ({
      date: point.date,
      value: Math.max(0, point.value * seasonalIndices[i % 12]),
    }));

    return forecast;
  }

  /**
   * Calculate seasonal indices for monthly data
   */
  private static calculateSeasonalIndices(values: number[]): number[] {
    const monthlyAverages = new Array(12).fill(0);
    const monthlyCounts = new Array(12).fill(0);

    // Calculate average for each month
    values.forEach((value, i) => {
      const month = i % 12;
      monthlyAverages[month] += value;
      monthlyCounts[month]++;
    });

    // Calculate monthly averages
    for (let i = 0; i < 12; i++) {
      monthlyAverages[i] = monthlyCounts[i] > 0 ? monthlyAverages[i] / monthlyCounts[i] : 1;
    }

    // Calculate overall average
    const overallAverage = monthlyAverages.reduce((sum, avg) => sum + avg, 0) / 12;

    // Calculate seasonal indices
    return monthlyAverages.map(avg => avg / overallAverage);
  }

  /**
   * Calculate trend from smoothed values
   */
  private static calculateTrend(values: number[]): number {
    if (values.length < 2) return 0;

    const n = values.length;
    const x = values.map((_, i) => i);
    const y = values;

    const sumX = x.reduce((a, b) => a + b, 0);
    const sumY = y.reduce((a, b) => a + b, 0);
    const sumXY = x.reduce((sum, xi, i) => sum + xi * y[i], 0);
    const sumXX = x.reduce((sum, xi) => sum + xi * xi, 0);

    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    const avgY = sumY / n;

    return slope / avgY; // Return as percentage change per period
  }

  /**
   * Select best forecasting method based on historical data characteristics
   */
  private static selectBestMethod(historical: ForecastPoint[]): 'linear' | 'exponential' | 'seasonal' {
    const values = historical.map(d => d.value);
    
    // Check for seasonality (if we have at least 24 months of data)
    if (values.length >= 24) {
      const seasonality = this.detectSeasonality(values);
      if (seasonality > 0.3) {
        return 'seasonal';
      }
    }

    // Check for exponential growth pattern
    const growthRates = [];
    for (let i = 1; i < values.length; i++) {
      if (values[i - 1] > 0) {
        growthRates.push((values[i] - values[i - 1]) / values[i - 1]);
      }
    }

    const avgGrowthRate = growthRates.reduce((sum, rate) => sum + rate, 0) / growthRates.length;
    const growthVariance = growthRates.reduce((sum, rate) => sum + Math.pow(rate - avgGrowthRate, 2), 0) / growthRates.length;

    // If growth rate is consistent and positive, use exponential
    if (avgGrowthRate > 0.02 && growthVariance < 0.01) {
      return 'exponential';
    }

    // Default to linear
    return 'linear';
  }

  /**
   * Detect seasonality in time series data
   */
  private static detectSeasonality(values: number[]): number {
    if (values.length < 24) return 0;

    // Calculate autocorrelation at lag 12 (for monthly seasonality)
    const lag = 12;
    const n = values.length - lag;
    
    const mean = values.reduce((sum, val) => sum + val, 0) / values.length;
    
    let numerator = 0;
    let denominator = 0;

    for (let i = 0; i < n; i++) {
      numerator += (values[i] - mean) * (values[i + lag] - mean);
    }

    for (let i = 0; i < values.length; i++) {
      denominator += Math.pow(values[i] - mean, 2);
    }

    return denominator > 0 ? Math.abs(numerator / denominator) : 0;
  }

  /**
   * Add confidence intervals to forecast
   */
  private static addConfidenceIntervals(
    forecast: ForecastPoint[],
    historical: ForecastPoint[],
    confidence: number
  ): ForecastPoint[] {
    // Calculate historical variance
    const values = historical.map(d => d.value);
    const mean = values.reduce((sum, val) => sum + val, 0) / values.length;
    const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / (values.length - 1);
    const stdDev = Math.sqrt(variance);

    // Z-score for confidence level
    const zScore = confidence === 0.95 ? 1.96 : confidence === 0.99 ? 2.58 : 1.645;

    return forecast.map((point, i) => ({
      ...point,
      confidence: Math.max(0.5, confidence - (i * 0.05)), // Decrease confidence over time
      upperBound: point.value + (zScore * stdDev * Math.sqrt(i + 1)),
      lowerBound: Math.max(0, point.value - (zScore * stdDev * Math.sqrt(i + 1))),
    }));
  }

  /**
   * Calculate forecast accuracy metrics
   */
  private static calculateAccuracy(historical: ForecastPoint[], method: string): ForecastResult['accuracy'] {
    if (historical.length < 6) {
      return { mape: 0, rmse: 0, r2: 0 };
    }

    // Use last 6 months for validation
    const validationSize = Math.min(6, Math.floor(historical.length / 3));
    const trainData = historical.slice(0, -validationSize);
    const testData = historical.slice(-validationSize);

    // Generate forecast for validation period
    let forecast: ForecastPoint[];
    switch (method) {
      case 'exponential':
        forecast = this.exponentialForecast(trainData, validationSize);
        break;
      case 'seasonal':
        forecast = this.seasonalForecast(trainData, validationSize);
        break;
      default:
        forecast = this.linearForecast(trainData, validationSize);
    }

    // Calculate metrics
    const actualValues = testData.map(d => d.value);
    const forecastValues = forecast.map(d => d.value);

    // MAPE (Mean Absolute Percentage Error)
    const mape = actualValues.reduce((sum, actual, i) => {
      if (actual !== 0) {
        return sum + Math.abs((actual - forecastValues[i]) / actual);
      }
      return sum;
    }, 0) / actualValues.length * 100;

    // RMSE (Root Mean Square Error)
    const rmse = Math.sqrt(
      actualValues.reduce((sum, actual, i) => {
        return sum + Math.pow(actual - forecastValues[i], 2);
      }, 0) / actualValues.length
    );

    // R-squared
    const actualMean = actualValues.reduce((sum, val) => sum + val, 0) / actualValues.length;
    const totalSumSquares = actualValues.reduce((sum, val) => sum + Math.pow(val - actualMean, 2), 0);
    const residualSumSquares = actualValues.reduce((sum, actual, i) => {
      return sum + Math.pow(actual - forecastValues[i], 2);
    }, 0);
    const r2 = totalSumSquares > 0 ? 1 - (residualSumSquares / totalSumSquares) : 0;

    return { mape, rmse, r2 };
  }

  /**
   * Generate different forecast scenarios
   */
  private static generateScenarios(
    baseForecast: ForecastPoint[],
    historical: ForecastPoint[]
  ): ForecastResult['scenarios'] {
    // Calculate historical volatility
    const values = historical.map(d => d.value);
    const returns = [];
    for (let i = 1; i < values.length; i++) {
      if (values[i - 1] > 0) {
        returns.push((values[i] - values[i - 1]) / values[i - 1]);
      }
    }

    const avgReturn = returns.reduce((sum, ret) => sum + ret, 0) / returns.length;
    const volatility = Math.sqrt(
      returns.reduce((sum, ret) => sum + Math.pow(ret - avgReturn, 2), 0) / (returns.length - 1)
    );

    return {
      conservative: baseForecast.map(point => ({
        ...point,
        value: point.value * (1 - volatility),
      })),
      optimistic: baseForecast.map(point => ({
        ...point,
        value: point.value * (1 + volatility * 1.5),
      })),
      pessimistic: baseForecast.map(point => ({
        ...point,
        value: Math.max(0, point.value * (1 - volatility * 2)),
      })),
    };
  }

  /**
   * Forecast operational metrics
   */
  static async forecastOperationalMetric(
    companyId: string,
    metric: string,
    periods: number,
    method: 'linear' | 'exponential' | 'seasonal' | 'auto' = 'auto'
  ): Promise<ForecastResult> {
    try {
      // Get historical operational data
      const historicalData = await OperationalData.find({
        companyId,
        period: 'monthly',
        'metadata.validated': true,
      })
      .sort({ date: -1 })
      .limit(24)
      .lean();

      if (historicalData.length < 6) {
        throw new AppError('Insufficient historical data for operational forecasting', 400);
      }

      historicalData.reverse();

      // Extract metric values based on the requested metric
      const historical: ForecastPoint[] = historicalData.map(d => ({
        date: d.date,
        value: this.extractOperationalMetricValue(d, metric),
      }));

      // Use the same forecasting logic as revenue
      const selectedMethod = method === 'auto' ? this.selectBestMethod(historical) : method;

      let forecast: ForecastPoint[];
      switch (selectedMethod) {
        case 'linear':
          forecast = this.linearForecast(historical, periods);
          break;
        case 'exponential':
          forecast = this.exponentialForecast(historical, periods);
          break;
        case 'seasonal':
          forecast = this.seasonalForecast(historical, periods);
          break;
        default:
          forecast = this.linearForecast(historical, periods);
      }

      const accuracy = this.calculateAccuracy(historical, selectedMethod);
      const scenarios = this.generateScenarios(forecast, historical);

      return {
        historical,
        forecast,
        method: selectedMethod,
        accuracy,
        scenarios,
      };
    } catch (error) {
      logger.error(`Error forecasting operational metric ${metric}:`, error);
      throw error;
    }
  }

  /**
   * Extract specific operational metric value from data
   */
  private static extractOperationalMetricValue(data: any, metric: string): number {
    const metricPaths: { [key: string]: string } = {
      'employee_productivity': 'employees.productivity.overall',
      'customer_satisfaction': 'customers.satisfactionScore',
      'inventory_turnover': 'inventory.turnoverRate',
      'production_efficiency': 'production.efficiency',
      'system_uptime': 'technology.systemUptime',
    };

    const path = metricPaths[metric];
    if (!path) {
      throw new AppError(`Unknown operational metric: ${metric}`, 400);
    }

    // Navigate nested object path
    const pathParts = path.split('.');
    let value = data;
    for (const part of pathParts) {
      value = value?.[part];
      if (value === undefined || value === null) {
        return 0;
      }
    }

    return typeof value === 'number' ? value : 0;
  }
}