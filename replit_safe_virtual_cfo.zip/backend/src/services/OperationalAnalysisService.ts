import { OperationalData, IOperationalData } from '../models/OperationalData';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';
import { redisClient } from '../config/redis';

export class OperationalAnalysisService {
  
  /**
   * Get comprehensive operational metrics
   */
  static async getOperationalMetrics(companyId: string, startDate: Date, endDate: Date, department?: string) {
    try {
      const cacheKey = `operational_metrics:${companyId}:${startDate.toISOString()}:${endDate.toISOString()}:${department || 'all'}`;
      
      // Check cache first
      const cachedData = await redisClient.get(cacheKey);
      if (cachedData) {
        return JSON.parse(cachedData);
      }

      const data = await OperationalData.find({
        companyId,
        date: { $gte: startDate, $lte: endDate },
        'metadata.validated': true,
      }).sort({ date: -1 }).lean();

      if (data.length === 0) {
        throw new AppError('No operational data found for the specified period', 404);
      }

      const latestData = data[0];
      
      // Calculate metrics
      const metrics = {
        productivity: {
          overall: latestData.employees.productivity.overall,
          byDepartment: Object.fromEntries(Object.entries(latestData.employees.productivity.byDepartment)),
          trend: this.calculateProductivityTrend(data)
        },
        efficiency: {
          production: latestData.production.efficiency,
          overall: this.calculateOverallEfficiency(latestData),
          bottlenecks: this.identifyBottlenecks(latestData)
        },
        quality: {
          score: latestData.production.qualityScore,
          defectRate: latestData.production.defectRate,
          customerSatisfaction: latestData.customers.satisfactionScore
        },
        departments: this.analyzeDepartmentPerformance(data),
        inventory: {
          turnover: latestData.inventory.turnoverRate,
          stockouts: latestData.inventory.stockouts,
          efficiency: this.calculateInventoryEfficiency(latestData)
        },
        customers: {
          total: latestData.customers.total,
          satisfaction: latestData.customers.satisfactionScore,
          churnRate: latestData.customers.churnRate,
          supportMetrics: latestData.customers.supportTickets
        }
      };

      // Cache for 10 minutes
      await redisClient.set(cacheKey, JSON.stringify(metrics), 600);

      return metrics;
    } catch (error) {
      logger.error('Error getting operational metrics:', error);
      throw error;
    }
  }

  /**
   * Get efficiency analysis
   */
  static async getEfficiencyAnalysis(companyId: string, period: string) {
    try {
      const endDate = new Date();
      const startDate = new Date();
      
      // Set date range based on period
      switch (period) {
        case 'weekly':
          startDate.setDate(startDate.getDate() - 7);
          break;
        case 'monthly':
          startDate.setMonth(startDate.getMonth() - 1);
          break;
        case 'quarterly':
          startDate.setMonth(startDate.getMonth() - 3);
          break;
        default:
          startDate.setMonth(startDate.getMonth() - 1);
      }

      const data = await OperationalData.find({
        companyId,
        date: { $gte: startDate, $lte: endDate },
        period,
        'metadata.validated': true,
      }).sort({ date: 1 }).lean();

      if (data.length === 0) {
        throw new AppError('No data available for efficiency analysis', 404);
      }

      // Calculate efficiency metrics
      const efficiencyAnalysis = {
        overall: {
          current: data[data.length - 1].production.efficiency,
          average: data.reduce((sum, d) => sum + d.production.efficiency, 0) / data.length,
          trend: this.calculateEfficiencyTrend(data)
        },
        processes: this.analyzeProcessEfficiency(data),
        recommendations: this.generateEfficiencyRecommendations(data),
        benchmarks: this.calculateEfficiencyBenchmarks(data)
      };

      return efficiencyAnalysis;
    } catch (error) {
      logger.error('Error getting efficiency analysis:', error);
      throw error;
    }
  }

  /**
   * Get department performance analysis
   */
  static async getDepartmentPerformance(companyId: string) {
    try {
      const latestData = await OperationalData.findOne({
        companyId,
        'metadata.validated': true,
      }).sort({ date: -1 }).lean();

      if (!latestData) {
        throw new AppError('No operational data available', 404);
      }

      // Simulate department data (in real implementation, this would come from the data)
      const departments = [
        {
          name: 'Production',
          efficiency: latestData.production.efficiency,
          productivity: latestData.employees.productivity.overall,
          quality: latestData.production.qualityScore,
          status: this.getDepartmentStatus(latestData.production.efficiency)
        },
        {
          name: 'Sales',
          efficiency: 88,
          productivity: 85,
          quality: 92,
          status: this.getDepartmentStatus(88)
        },
        {
          name: 'Customer Service',
          efficiency: 95,
          productivity: latestData.customers.satisfactionScore,
          quality: 98,
          status: this.getDepartmentStatus(95)
        },
        {
          name: 'Logistics',
          efficiency: 87,
          productivity: 91,
          quality: 89,
          status: this.getDepartmentStatus(87)
        }
      ];

      return departments;
    } catch (error) {
      logger.error('Error getting department performance:', error);
      throw error;
    }
  }

  /**
   * Calculate productivity trend
   */
  private static calculateProductivityTrend(data: IOperationalData[]) {
    if (data.length < 2) return 'stable';

    const recent = data.slice(0, Math.min(3, data.length));
    const older = data.slice(Math.min(3, data.length));

    if (older.length === 0) return 'stable';

    const recentAvg = recent.reduce((sum, d) => sum + d.employees.productivity.overall, 0) / recent.length;
    const olderAvg = older.reduce((sum, d) => sum + d.employees.productivity.overall, 0) / older.length;

    const change = ((recentAvg - olderAvg) / olderAvg) * 100;

    if (change > 5) return 'increasing';
    if (change < -5) return 'decreasing';
    return 'stable';
  }

  /**
   * Calculate overall efficiency
   */
  private static calculateOverallEfficiency(data: IOperationalData) {
    const weights = {
      production: 0.4,
      employees: 0.3,
      inventory: 0.2,
      technology: 0.1
    };

    return (
      data.production.efficiency * weights.production +
      data.employees.productivity.overall * weights.employees +
      (data.inventory.turnoverRate * 10) * weights.inventory + // Normalize turnover rate
      data.technology.systemUptime * weights.technology
    );
  }

  /**
   * Identify bottlenecks
   */
  private static identifyBottlenecks(data: IOperationalData) {
    const bottlenecks = [];

    if (data.production.efficiency < 80) {
      bottlenecks.push({
        area: 'Production',
        severity: 'high',
        description: 'Production efficiency below target'
      });
    }

    if (data.inventory.turnoverRate < 4) {
      bottlenecks.push({
        area: 'Inventory',
        severity: 'medium',
        description: 'Low inventory turnover rate'
      });
    }

    if (data.customers.supportTickets.avgResolutionTime > 24) {
      bottlenecks.push({
        area: 'Customer Support',
        severity: 'medium',
        description: 'High support ticket resolution time'
      });
    }

    return bottlenecks;
  }

  /**
   * Analyze department performance
   */
  private static analyzeDepartmentPerformance(data: IOperationalData[]) {
    const latestData = data[0];
    
    return {
      production: {
        efficiency: latestData.production.efficiency,
        output: latestData.production.output,
        quality: latestData.production.qualityScore
      },
      hr: {
        productivity: latestData.employees.productivity.overall,
        turnover: latestData.employees.turnoverRate,
        total: latestData.employees.total
      },
      customerService: {
        satisfaction: latestData.customers.satisfactionScore,
        responseTime: latestData.customers.supportTickets.avgResolutionTime,
        ticketResolution: (latestData.customers.supportTickets.resolved / latestData.customers.supportTickets.total) * 100
      }
    };
  }

  /**
   * Calculate inventory efficiency
   */
  private static calculateInventoryEfficiency(data: IOperationalData) {
    const turnoverScore = Math.min(data.inventory.turnoverRate / 6 * 100, 100); // Target: 6x turnover
    const stockoutPenalty = data.inventory.stockouts * 5; // 5% penalty per stockout
    
    return Math.max(turnoverScore - stockoutPenalty, 0);
  }

  /**
   * Calculate efficiency trend
   */
  private static calculateEfficiencyTrend(data: IOperationalData[]) {
    if (data.length < 2) return 'stable';

    const firstHalf = data.slice(0, Math.floor(data.length / 2));
    const secondHalf = data.slice(Math.floor(data.length / 2));

    const firstAvg = firstHalf.reduce((sum, d) => sum + d.production.efficiency, 0) / firstHalf.length;
    const secondAvg = secondHalf.reduce((sum, d) => sum + d.production.efficiency, 0) / secondHalf.length;

    const change = ((secondAvg - firstAvg) / firstAvg) * 100;

    if (change > 3) return 'improving';
    if (change < -3) return 'declining';
    return 'stable';
  }

  /**
   * Analyze process efficiency
   */
  private static analyzeProcessEfficiency(data: IOperationalData[]) {
    const latestData = data[data.length - 1];
    const processes = [];

    // Convert Map to array for analysis
    for (const [processName, processData] of latestData.processes) {
      processes.push({
        name: processName,
        efficiency: processData.efficiency,
        cycleTime: processData.cycleTime,
        errorRate: processData.errorRate,
        cost: processData.cost,
        bottlenecks: processData.bottlenecks,
        status: processData.efficiency > 90 ? 'excellent' : processData.efficiency > 75 ? 'good' : 'needs_improvement'
      });
    }

    return processes;
  }

  /**
   * Generate efficiency recommendations
   */
  private static generateEfficiencyRecommendations(data: IOperationalData[]) {
    const latestData = data[data.length - 1];
    const recommendations = [];

    if (latestData.production.efficiency < 85) {
      recommendations.push({
        area: 'Production',
        priority: 'high',
        recommendation: 'Implement lean manufacturing principles to reduce waste and improve efficiency'
      });
    }

    if (latestData.inventory.turnoverRate < 4) {
      recommendations.push({
        area: 'Inventory',
        priority: 'medium',
        recommendation: 'Optimize inventory levels and improve demand forecasting'
      });
    }

    if (latestData.employees.productivity.overall < 80) {
      recommendations.push({
        area: 'Human Resources',
        priority: 'medium',
        recommendation: 'Provide additional training and implement productivity incentives'
      });
    }

    return recommendations;
  }

  /**
   * Calculate efficiency benchmarks
   */
  private static calculateEfficiencyBenchmarks(data: IOperationalData[]) {
    const efficiencyValues = data.map(d => d.production.efficiency);
    
    return {
      industry_average: 82, // This would come from industry data
      top_quartile: 90,
      current: efficiencyValues[efficiencyValues.length - 1],
      best_in_period: Math.max(...efficiencyValues),
      worst_in_period: Math.min(...efficiencyValues)
    };
  }

  /**
   * Get department status based on efficiency
   */
  private static getDepartmentStatus(efficiency: number): 'excellent' | 'good' | 'needs_improvement' {
    if (efficiency >= 90) return 'excellent';
    if (efficiency >= 75) return 'good';
    return 'needs_improvement';
  }
}