import { FinancialData } from '../models/FinancialData';
import { OperationalData } from '../models/OperationalData';
import { FinancialAnalysisService } from './FinancialAnalysisService';
import { OperationalAnalysisService } from './OperationalAnalysisService';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';
import { redisClient } from '../config/redis';

export class AnalyticsService {
  
  /**
   * Get comprehensive dashboard data
   */
  static async getDashboardData(companyId: string) {
    try {
      const cacheKey = `dashboard:${companyId}`;
      
      // Check cache first
      const cachedData = await redisClient.get(cacheKey);
      if (cachedData) {
        return JSON.parse(cachedData);
      }

      // Get current date range (last 30 days)
      const endDate = new Date();
      const startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

      // Fetch financial and operational data in parallel
      const [financialSummary, operationalMetrics, kpis] = await Promise.all([
        FinancialAnalysisService.generateFinancialSummary(companyId, startDate, endDate),
        OperationalAnalysisService.getOperationalMetrics(companyId, startDate, endDate),
        this.calculateKPIs(companyId, 'monthly')
      ]);

      const dashboardData = {
        financial: {
          revenue: financialSummary.current.revenue,
          profit: financialSummary.current.netProfit,
          expenses: financialSummary.current.expenses,
          margins: financialSummary.current.margins,
          trends: financialSummary.trends,
          healthScore: financialSummary.healthAssessment.overallScore
        },
        operational: {
          productivity: operationalMetrics.productivity,
          efficiency: operationalMetrics.efficiency,
          quality: operationalMetrics.quality,
          departments: operationalMetrics.departments
        },
        kpis,
        alerts: await this.generateAlerts(companyId),
        lastUpdated: new Date().toISOString()
      };

      // Cache for 5 minutes
      await redisClient.set(cacheKey, JSON.stringify(dashboardData), 300);

      return dashboardData;
    } catch (error) {
      logger.error('Error getting dashboard data:', error);
      throw error;
    }
  }

  /**
   * Calculate key performance indicators
   */
  static async calculateKPIs(companyId: string, period: string) {
    try {
      const endDate = new Date();
      const startDate = new Date();
      
      // Set date range based on period
      switch (period) {
        case 'weekly':
          startDate.setDate(startDate.getDate() - 7);
          break;
        case 'monthly':
          startDate.setMonth(startDate.getMonth() - 1);
          break;
        case 'quarterly':
          startDate.setMonth(startDate.getMonth() - 3);
          break;
        case 'yearly':
          startDate.setFullYear(startDate.getFullYear() - 1);
          break;
        default:
          startDate.setMonth(startDate.getMonth() - 1);
      }

      // Get latest financial and operational data
      const [latestFinancial, latestOperational] = await Promise.all([
        FinancialData.findOne({
          companyId,
          date: { $lte: endDate },
          'metadata.validated': true,
        }).sort({ date: -1 }).lean(),
        
        OperationalData.findOne({
          companyId,
          date: { $lte: endDate },
          'metadata.validated': true,
        }).sort({ date: -1 }).lean()
      ]);

      if (!latestFinancial || !latestOperational) {
        throw new AppError('Insufficient data for KPI calculation', 404);
      }

      // Calculate financial KPIs
      const financialKPIs = {
        revenue: {
          value: latestFinancial.revenue.total,
          change: await this.calculateChange(companyId, 'revenue', period),
          trend: 'up' as const
        },
        profitMargin: {
          value: latestFinancial.profitability.margins.net,
          change: await this.calculateChange(companyId, 'profitMargin', period),
          trend: 'up' as const
        },
        cashFlow: {
          value: latestFinancial.cashFlow.net,
          change: await this.calculateChange(companyId, 'cashFlow', period),
          trend: 'up' as const
        },
        currentRatio: {
          value: latestFinancial.ratios.liquidity.current,
          change: await this.calculateChange(companyId, 'currentRatio', period),
          trend: 'stable' as const
        }
      };

      // Calculate operational KPIs
      const operationalKPIs = {
        productivity: {
          value: latestOperational.employees.productivity.overall,
          change: await this.calculateChange(companyId, 'productivity', period),
          trend: 'up' as const
        },
        efficiency: {
          value: latestOperational.production.efficiency,
          change: await this.calculateChange(companyId, 'efficiency', period),
          trend: 'up' as const
        },
        customerSatisfaction: {
          value: latestOperational.customers.satisfactionScore,
          change: await this.calculateChange(companyId, 'customerSatisfaction', period),
          trend: 'up' as const
        },
        inventoryTurnover: {
          value: latestOperational.inventory.turnoverRate,
          change: await this.calculateChange(companyId, 'inventoryTurnover', period),
          trend: 'up' as const
        }
      };

      return {
        financial: financialKPIs,
        operational: operationalKPIs,
        period,
        calculatedAt: new Date().toISOString()
      };
    } catch (error) {
      logger.error('Error calculating KPIs:', error);
      throw error;
    }
  }

  /**
   * Get trend analysis for specific metrics
   */
  static async getTrendAnalysis(companyId: string, metric: string, period: string, months: number) {
    try {
      const endDate = new Date();
      const startDate = new Date();
      startDate.setMonth(startDate.getMonth() - months);

      let data: any[];
      let valueExtractor: (item: any) => number;

      // Determine data source and value extractor based on metric
      switch (metric) {
        case 'revenue':
          data = await FinancialData.find({
            companyId,
            date: { $gte: startDate, $lte: endDate },
            period,
            'metadata.validated': true,
          }).sort({ date: 1 }).lean();
          valueExtractor = (item) => item.revenue.total;
          break;
          
        case 'profit':
          data = await FinancialData.find({
            companyId,
            date: { $gte: startDate, $lte: endDate },
            period,
            'metadata.validated': true,
          }).sort({ date: 1 }).lean();
          valueExtractor = (item) => item.profitability.netProfit;
          break;
          
        case 'productivity':
          data = await OperationalData.find({
            companyId,
            date: { $gte: startDate, $lte: endDate },
            period,
            'metadata.validated': true,
          }).sort({ date: 1 }).lean();
          valueExtractor = (item) => item.employees.productivity.overall;
          break;
          
        default:
          throw new AppError(`Unknown metric: ${metric}`, 400);
      }

      if (data.length === 0) {
        throw new AppError('No data available for trend analysis', 404);
      }

      // Calculate trend
      const trendData = data.map(item => ({
        date: item.date,
        value: valueExtractor(item)
      }));

      const trend = this.calculateTrendDirection(trendData);

      return {
        metric,
        period,
        data: trendData,
        trend,
        summary: {
          total: trendData.length,
          average: trendData.reduce((sum, item) => sum + item.value, 0) / trendData.length,
          min: Math.min(...trendData.map(item => item.value)),
          max: Math.max(...trendData.map(item => item.value)),
          latest: trendData[trendData.length - 1]?.value || 0
        }
      };
    } catch (error) {
      logger.error('Error getting trend analysis:', error);
      throw error;
    }
  }

  /**
   * Process uploaded data and update analytics
   */
  static async processUploadedData(companyId: string, fileId: string, dataType: string) {
    try {
      logger.info('Processing uploaded data', { companyId, fileId, dataType });

      // Find the uploaded data
      let dataRecord;
      if (dataType === 'financial') {
        dataRecord = await FinancialData.findOne({ _id: fileId, companyId });
      } else {
        dataRecord = await OperationalData.findOne({ _id: fileId, companyId });
      }

      if (!dataRecord) {
        throw new AppError('Data record not found', 404);
      }

      // Mark as validated and processed
      dataRecord.metadata.validated = true;
      await dataRecord.save();

      // Clear relevant caches
      await this.clearAnalyticsCache(companyId);

      // Recalculate analytics
      const updatedAnalytics = await this.getDashboardData(companyId);

      logger.info('Data processed successfully', { companyId, fileId, dataType });

      return {
        processed: true,
        recordId: fileId,
        dataType,
        updatedAnalytics
      };
    } catch (error) {
      logger.error('Error processing uploaded data:', error);
      throw error;
    }
  }

  /**
   * Generate alerts based on current data
   */
  private static async generateAlerts(companyId: string) {
    try {
      const alerts = [];

      // Get latest financial data
      const latestFinancial = await FinancialData.findOne({
        companyId,
        'metadata.validated': true,
      }).sort({ date: -1 }).lean();

      if (latestFinancial) {
        // Check for low cash flow
        if (latestFinancial.cashFlow.net < 0) {
          alerts.push({
            type: 'warning',
            message: 'Negative cash flow detected',
            severity: 'high',
            timestamp: new Date().toISOString()
          });
        }

        // Check for low current ratio
        if (latestFinancial.ratios.liquidity.current < 1.5) {
          alerts.push({
            type: 'warning',
            message: 'Current ratio below recommended threshold',
            severity: 'medium',
            timestamp: new Date().toISOString()
          });
        }

        // Check for high debt-to-equity ratio
        if (latestFinancial.ratios.leverage.debtToEquity > 2) {
          alerts.push({
            type: 'error',
            message: 'High debt-to-equity ratio detected',
            severity: 'high',
            timestamp: new Date().toISOString()
          });
        }
      }

      // Get latest operational data
      const latestOperational = await OperationalData.findOne({
        companyId,
        'metadata.validated': true,
      }).sort({ date: -1 }).lean();

      if (latestOperational) {
        // Check for low productivity
        if (latestOperational.employees.productivity.overall < 80) {
          alerts.push({
            type: 'warning',
            message: 'Employee productivity below target',
            severity: 'medium',
            timestamp: new Date().toISOString()
          });
        }

        // Check for high customer churn
        if (latestOperational.customers.churnRate > 10) {
          alerts.push({
            type: 'error',
            message: 'Customer churn rate exceeds threshold',
            severity: 'high',
            timestamp: new Date().toISOString()
          });
        }
      }

      return alerts;
    } catch (error) {
      logger.error('Error generating alerts:', error);
      return [];
    }
  }

  /**
   * Calculate percentage change for a metric
   */
  private static async calculateChange(companyId: string, metric: string, period: string): Promise<number> {
    try {
      // This is a simplified implementation
      // In a real system, you'd calculate actual percentage changes
      return Math.random() * 20 - 10; // Random change between -10% and +10%
    } catch (error) {
      logger.error('Error calculating change:', error);
      return 0;
    }
  }

  /**
   * Calculate trend direction from data points
   */
  private static calculateTrendDirection(data: { date: Date; value: number }[]) {
    if (data.length < 2) return 'stable';

    const firstHalf = data.slice(0, Math.floor(data.length / 2));
    const secondHalf = data.slice(Math.floor(data.length / 2));

    const firstAvg = firstHalf.reduce((sum, item) => sum + item.value, 0) / firstHalf.length;
    const secondAvg = secondHalf.reduce((sum, item) => sum + item.value, 0) / secondHalf.length;

    const changePercent = ((secondAvg - firstAvg) / firstAvg) * 100;

    if (changePercent > 5) return 'increasing';
    if (changePercent < -5) return 'decreasing';
    return 'stable';
  }

  /**
   * Clear analytics cache
   */
  private static async clearAnalyticsCache(companyId: string) {
    try {
      const cacheKeys = [
        `dashboard:${companyId}`,
        `financial_trends:${companyId}:*`,
        `operational_metrics:${companyId}:*`
      ];

      for (const key of cacheKeys) {
        await redisClient.del(key);
      }
    } catch (error) {
      logger.error('Error clearing analytics cache:', error);
    }
  }
}