import { Request, Response, NextFunction } from 'express';
import Joi from 'joi';
import { logger } from '../utils/logger';

export const validateRequest = (schema: {
  body?: Joi.ObjectSchema;
  query?: Joi.ObjectSchema;
  params?: Joi.ObjectSchema;
}) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    const errors: string[] = [];

    // Validate request body
    if (schema.body) {
      const { error } = schema.body.validate(req.body);
      if (error) {
        errors.push(`Body: ${error.details.map(d => d.message).join(', ')}`);
      }
    }

    // Validate query parameters
    if (schema.query) {
      const { error } = schema.query.validate(req.query);
      if (error) {
        errors.push(`Query: ${error.details.map(d => d.message).join(', ')}`);
      }
    }

    // Validate route parameters
    if (schema.params) {
      const { error } = schema.params.validate(req.params);
      if (error) {
        errors.push(`Params: ${error.details.map(d => d.message).join(', ')}`);
      }
    }

    if (errors.length > 0) {
      logger.warn('Validation error:', {
        path: req.path,
        method: req.method,
        errors,
        body: req.body,
        query: req.query,
        params: req.params,
      });

      res.status(400).json({
        success: false,
        message: 'Validation error',
        errors,
      });
      return;
    }

    next();
  };
};

// Common validation schemas
export const schemas = {
  // Authentication schemas
  register: {
    body: Joi.object({
      email: Joi.string().email().required(),
      password: Joi.string().min(8).required(),
      firstName: Joi.string().min(2).max(50).required(),
      lastName: Joi.string().min(2).max(50).required(),
      companyName: Joi.string().min(2).max(100).required(),
      role: Joi.string().valid('admin', 'analyst', 'viewer').default('analyst'),
    }),
  },

  login: {
    body: Joi.object({
      email: Joi.string().email().required(),
      password: Joi.string().required(),
    }),
  },

  // Data upload schemas
  dataUpload: {
    body: Joi.object({
      fileName: Joi.string().required(),
      fileType: Joi.string().valid('csv', 'xlsx', 'json', 'xml').required(),
      dataType: Joi.string().valid('financial', 'operational', 'hr', 'sales').required(),
      data: Joi.array().items(Joi.object()).required(),
    }),
  },

  // Financial analysis schemas
  financialAnalysis: {
    query: Joi.object({
      startDate: Joi.date().iso(),
      endDate: Joi.date().iso().min(Joi.ref('startDate')),
      period: Joi.string().valid('daily', 'weekly', 'monthly', 'quarterly', 'yearly').default('monthly'),
      metrics: Joi.array().items(Joi.string()).default(['revenue', 'profit', 'expenses']),
    }),
  },

  // Report generation schemas
  reportGeneration: {
    body: Joi.object({
      reportType: Joi.string().valid('financial', 'operational', 'comprehensive').required(),
      dateRange: Joi.object({
        startDate: Joi.date().iso().required(),
        endDate: Joi.date().iso().min(Joi.ref('startDate')).required(),
      }).required(),
      sections: Joi.array().items(Joi.string()).default(['summary', 'metrics', 'trends']),
      format: Joi.string().valid('pdf', 'excel', 'json').default('pdf'),
    }),
  },

  // Forecasting schemas
  forecasting: {
    body: Joi.object({
      metric: Joi.string().required(),
      periods: Joi.number().integer().min(1).max(24).required(),
      method: Joi.string().valid('linear', 'exponential', 'seasonal').default('linear'),
      confidence: Joi.number().min(0.5).max(0.99).default(0.95),
    }),
  },
};