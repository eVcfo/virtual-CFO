import express from 'express';
import { AnalyticsService } from '../services/AnalyticsService';
import { validateRequest, schemas } from '../middleware/validation';
import { AuthenticatedRequest } from '../middleware/auth';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';

const router = express.Router();

/**
 * GET /api/analytics/dashboard
 * Get real-time dashboard data
 */
router.get('/dashboard', async (req: AuthenticatedRequest, res) => {
  try {
    const companyId = req.user!.companyId;
    const dashboardData = await AnalyticsService.getDashboardData(companyId);

    res.json({
      success: true,
      data: dashboardData,
    });
  } catch (error) {
    logger.error('Error fetching dashboard data:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * GET /api/analytics/kpis
 * Get key performance indicators
 */
router.get('/kpis', async (req: AuthenticatedRequest, res) => {
  try {
    const companyId = req.user!.companyId;
    const { period = 'monthly' } = req.query as any;
    
    const kpis = await AnalyticsService.calculateKPIs(companyId, period);

    res.json({
      success: true,
      data: kpis,
    });
  } catch (error) {
    logger.error('Error calculating KPIs:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * GET /api/analytics/trends
 * Get trend analysis
 */
router.get('/trends', async (req: AuthenticatedRequest, res) => {
  try {
    const companyId = req.user!.companyId;
    const { metric, period = 'monthly', months = 12 } = req.query as any;
    
    const trends = await AnalyticsService.getTrendAnalysis(companyId, metric, period, parseInt(months));

    res.json({
      success: true,
      data: trends,
    });
  } catch (error) {
    logger.error('Error getting trend analysis:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * POST /api/analytics/process-data
 * Process uploaded data and update analytics
 */
router.post('/process-data', async (req: AuthenticatedRequest, res) => {
  try {
    const companyId = req.user!.companyId;
    const { fileId, dataType } = req.body;
    
    if (!fileId || !dataType) {
      throw new AppError('File ID and data type are required', 400);
    }

    const result = await AnalyticsService.processUploadedData(companyId, fileId, dataType);

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    logger.error('Error processing uploaded data:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

export default router;