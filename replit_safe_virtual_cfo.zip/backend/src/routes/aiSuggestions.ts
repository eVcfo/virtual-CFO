import express from 'express';
import axios from 'axios';

const router = express.Router();

router.post('/', async (req, res) => {
  const insights = req.body.insights;
  if (!insights) {
    return res.status(400).json({ error: 'Missing insights' });
  }

  const prompt = `
You are a virtual CFO. Based on the following financial and operational data, suggest 5 actionable steps to improve the business's profitability, cash flow, or operational efficiency.

Data:
${JSON.stringify(insights, null, 2)}

Respond with clear and concise suggestions in bullet points.
  `;

  try {
    const response = await axios.post('http://localhost:11434/api/generate', {
      model: "mistral",
      prompt,
      stream: false
    });

    const text = response.data.response || '';
    const suggestions = text.split(/\n|\r|\*/).filter(line =>
      line.trim().length > 10
    );

    res.json({ suggestions });
  } catch (err) {
    console.warn('⚠️ Ollama not reachable. Returning mock suggestions.');
    res.json({
      suggestions: [
        "1. Reduce inventory holding days to improve working capital.",
        "2. Renegotiate vendor terms to defer payables and enhance cash flow.",
        "3. Identify low-margin products for possible discontinuation.",
        "4. Increase pricing selectively in high-margin product lines.",
        "5. Implement employee performance metrics to optimize operations."
      ]
    });
  }
});

export default router;