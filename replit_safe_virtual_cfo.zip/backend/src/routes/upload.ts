import express from 'express';
import multer from 'multer';
import path from 'path';
import { parseFinancialExcel } from '../services/FileParserService';
import { FinancialAnalysisService } from '../services/FinancialAnalysisService';
import { OperationalAnalysisService } from '../services/OperationalAnalysisService';

const router = express.Router();

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, path.join(__dirname, '../uploads')),
  filename: (_req, file, cb) => cb(null, file.originalname),
});

const upload = multer({ storage });

router.post('/upload', upload.single('file'), async (req, res) => {
  try {
    const filePath = req.file?.path;
    if (!filePath) return res.status(400).json({ error: 'No file uploaded' });

    const { financialData, operationalData } = await parseFinancialExcel(filePath);

    const financialInsights = FinancialAnalysisService.analyze(financialData);
    const operationalInsights = OperationalAnalysisService.analyze(operationalData);

    return res.json({
      success: true,
      financialInsights,
      operationalInsights,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;