import express from 'express';
import { ForecastingService } from '../services/ForecastingService';
import { validateRequest, schemas } from '../middleware/validation';
import { AuthenticatedRequest } from '../middleware/auth';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';

const router = express.Router();

/**
 * POST /api/forecasting/revenue
 * Generate revenue forecast
 */
router.post('/revenue', validateRequest({ body: schemas.forecasting.body }), async (req: AuthenticatedRequest, res) => {
  try {
    const { periods, method, confidence } = req.body;
    const companyId = req.user!.companyId;

    const forecast = await ForecastingService.forecastRevenue(companyId, periods, method, confidence);

    res.json({
      success: true,
      data: forecast,
    });
  } catch (error) {
    logger.error('Error in revenue forecasting endpoint:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * POST /api/forecasting/operational
 * Generate operational metric forecast
 */
router.post('/operational', async (req: AuthenticatedRequest, res) => {
  try {
    const { metric, periods, method = 'auto' } = req.body;
    const companyId = req.user!.companyId;

    if (!metric) {
      throw new AppError('Metric parameter is required', 400);
    }

    if (!periods || periods < 1 || periods > 24) {
      throw new AppError('Periods must be between 1 and 24', 400);
    }

    const forecast = await ForecastingService.forecastOperationalMetric(companyId, metric, periods, method);

    res.json({
      success: true,
      data: forecast,
    });
  } catch (error) {
    logger.error('Error in operational forecasting endpoint:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * GET /api/forecasting/scenarios
 * Get forecast scenarios for multiple metrics
 */
router.get('/scenarios', async (req: AuthenticatedRequest, res) => {
  try {
    const { periods = 12, metrics = 'revenue,profit,expenses' } = req.query as any;
    const companyId = req.user!.companyId;

    const metricList = metrics.split(',');
    const scenarios: any = {};

    // Generate forecasts for each requested metric
    for (const metric of metricList) {
      try {
        if (metric === 'revenue' || metric === 'profit' || metric === 'expenses') {
          const forecast = await ForecastingService.forecastRevenue(companyId, periods, 'auto');
          scenarios[metric] = {
            forecast: forecast.forecast,
            scenarios: forecast.scenarios,
            accuracy: forecast.accuracy,
          };
        } else {
          // Operational metric
          const forecast = await ForecastingService.forecastOperationalMetric(companyId, metric, periods, 'auto');
          scenarios[metric] = {
            forecast: forecast.forecast,
            scenarios: forecast.scenarios,
            accuracy: forecast.accuracy,
          };
        }
      } catch (metricError) {
        logger.warn(`Failed to forecast metric ${metric}:`, metricError);
        scenarios[metric] = {
          error: `Unable to forecast ${metric}: insufficient data`,
        };
      }
    }

    res.json({
      success: true,
      data: scenarios,
    });
  } catch (error) {
    logger.error('Error in forecast scenarios endpoint:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * GET /api/forecasting/accuracy
 * Get forecasting accuracy metrics
 */
router.get('/accuracy', async (req: AuthenticatedRequest, res) => {
  try {
    const { metric = 'revenue', method = 'auto' } = req.query as any;
    const companyId = req.user!.companyId;

    let forecast;
    if (metric === 'revenue') {
      forecast = await ForecastingService.forecastRevenue(companyId, 6, method); // 6 months for accuracy testing
    } else {
      forecast = await ForecastingService.forecastOperationalMetric(companyId, metric, 6, method);
    }

    res.json({
      success: true,
      data: {
        metric,
        method: forecast.method,
        accuracy: forecast.accuracy,
        dataPoints: forecast.historical.length,
        recommendations: {
          reliability: forecast.accuracy.r2 > 0.7 ? 'High' : forecast.accuracy.r2 > 0.4 ? 'Medium' : 'Low',
          suggestedMethod: forecast.method,
          confidenceLevel: forecast.accuracy.mape < 10 ? 'High' : forecast.accuracy.mape < 20 ? 'Medium' : 'Low',
        },
      },
    });
  } catch (error) {
    logger.error('Error in forecasting accuracy endpoint:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

export default router;