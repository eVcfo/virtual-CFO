import express from 'express';
import { OperationalAnalysisService } from '../services/OperationalAnalysisService';
import { validateRequest, schemas } from '../middleware/validation';
import { AuthenticatedRequest } from '../middleware/auth';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';

const router = express.Router();

/**
 * GET /api/operational/metrics
 * Get operational metrics
 */
router.get('/metrics', async (req: AuthenticatedRequest, res) => {
  try {
    const companyId = req.user!.companyId;
    const { startDate, endDate, department } = req.query as any;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();

    const metrics = await OperationalAnalysisService.getOperationalMetrics(companyId, start, end, department);

    res.json({
      success: true,
      data: metrics,
    });
  } catch (error) {
    logger.error('Error fetching operational metrics:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * GET /api/operational/efficiency
 * Get efficiency analysis
 */
router.get('/efficiency', async (req: AuthenticatedRequest, res) => {
  try {
    const companyId = req.user!.companyId;
    const { period = 'monthly' } = req.query as any;

    const efficiency = await OperationalAnalysisService.getEfficiencyAnalysis(companyId, period);

    res.json({
      success: true,
      data: efficiency,
    });
  } catch (error) {
    logger.error('Error getting efficiency analysis:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * GET /api/operational/departments
 * Get department performance
 */
router.get('/departments', async (req: AuthenticatedRequest, res) => {
  try {
    const companyId = req.user!.companyId;
    const departments = await OperationalAnalysisService.getDepartmentPerformance(companyId);

    res.json({
      success: true,
      data: departments,
    });
  } catch (error) {
    logger.error('Error getting department performance:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

export default router;