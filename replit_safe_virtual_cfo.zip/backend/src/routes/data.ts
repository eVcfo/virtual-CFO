import express from 'express';
import multer from 'multer';
import csv from 'csv-parser';
import * as XLSX from 'xlsx';
import { FinancialData } from '../models/FinancialData';
import { OperationalData } from '../models/OperationalData';
import { FinancialAnalysisService } from '../services/FinancialAnalysisService';
import { validateRequest, schemas } from '../middleware/validation';
import { AuthenticatedRequest } from '../middleware/auth';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';
import { Readable } from 'stream';

const router = express.Router();

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'text/csv',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/json',
      'application/xml',
      'text/xml',
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new AppError('Invalid file type. Only CSV, Excel, JSON, and XML files are allowed.', 400));
    }
  },
});

/**
 * POST /api/data/upload
 * Upload and process data files
 */
router.post('/upload', upload.single('file'), async (req: AuthenticatedRequest, res) => {
  try {
    if (!req.file) {
      throw new AppError('No file uploaded', 400);
    }

    const { dataType, period = 'monthly' } = req.body;
    const companyId = req.user!.companyId;
    const userId = req.user!.id;

    if (!dataType || !['financial', 'operational', 'hr', 'sales'].includes(dataType)) {
      throw new AppError('Invalid data type. Must be one of: financial, operational, hr, sales', 400);
    }

    // Parse file based on type
    let parsedData: any[];
    const fileExtension = req.file.originalname.split('.').pop()?.toLowerCase();

    switch (fileExtension) {
      case 'csv':
        parsedData = await parseCSV(req.file.buffer);
        break;
      case 'xlsx':
      case 'xls':
        parsedData = await parseExcel(req.file.buffer);
        break;
      case 'json':
        parsedData = JSON.parse(req.file.buffer.toString());
        break;
      default:
        throw new AppError('Unsupported file format', 400);
    }

    if (!Array.isArray(parsedData) || parsedData.length === 0) {
      throw new AppError('No valid data found in file', 400);
    }

    // Process data based on type
    let processedRecords = 0;
    const errors: string[] = [];

    if (dataType === 'financial') {
      processedRecords = await processFinancialData(parsedData, companyId, userId, period, errors);
    } else if (dataType === 'operational') {
      processedRecords = await processOperationalData(parsedData, companyId, userId, period, errors);
    } else {
      // For HR and sales data, we'll store them as operational data with specific categories
      processedRecords = await processGenericData(parsedData, companyId, userId, period, dataType, errors);
    }

    logger.info('Data upload processed', {
      fileName: req.file.originalname,
      dataType,
      recordsProcessed: processedRecords,
      errors: errors.length,
      companyId,
      userId,
    });

    res.json({
      success: true,
      message: 'Data uploaded and processed successfully',
      data: {
        fileName: req.file.originalname,
        recordsProcessed: 0,  // TODO: Replace 0 with actual value
        errors: errors.length > 0 ? errors : undefined,
        dataType,
        period,
      },
    });
  } catch (error) {
    logger.error('Data upload error:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Upload failed',
    });
  }
});

/**
 * GET /api/data/files
 * Get list of uploaded files
 */
router.get('/files', async (req: AuthenticatedRequest, res) => {
  try {
    const companyId = req.user!.companyId;
    const { dataType, limit = 50, offset = 0 } = req.query as any;

    const query: any = { companyId };
    if (dataType) {
      query['metadata.source'] = { $regex: dataType, $options: 'i' };
    }

    // Get financial data files
    const financialFiles = await FinancialData.find(query)
      .select('metadata date period createdAt')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip(parseInt(offset))
      .populate('metadata.uploadedBy', 'firstName lastName email');

    // Get operational data files
    const operationalFiles = await OperationalData.find(query)
      .select('metadata date period createdAt')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip(parseInt(offset))
      .populate('metadata.uploadedBy', 'firstName lastName email');

    // Combine and sort by creation date
    const allFiles = [...financialFiles, ...operationalFiles]
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, parseInt(limit));

    res.json({
      success: true,
      data: {
        files: allFiles,
        total: allFiles.length,
        hasMore: allFiles.length === parseInt(limit),
      },
    });
  } catch (error) {
    logger.error('Error fetching uploaded files:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch uploaded files',
    });
  }
});

/**
 * DELETE /api/data/files/:id
 * Delete uploaded data file
 */
router.delete('/files/:id', async (req: AuthenticatedRequest, res) => {
  try {
    const { id } = req.params;
    const companyId = req.user!.companyId;

    // Try to find and delete from both collections
    const financialResult = await FinancialData.findOneAndDelete({ _id: id, companyId });
    const operationalResult = await OperationalData.findOneAndDelete({ _id: id, companyId });

    if (!financialResult && !operationalResult) {
      throw new AppError('File not found or access denied', 404);
    }

    logger.info('Data file deleted', {
      fileId: id,
      companyId,
      userId: req.user!.id,
    });

    res.json({
      success: true,
      message: 'File deleted successfully',
    });
  } catch (error) {
    logger.error('Error deleting data file:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Failed to delete file',
    });
  }
});

/**
 * GET /api/data/validate/:id
 * Validate uploaded data
 */
router.post('/validate/:id', async (req: AuthenticatedRequest, res) => {
  try {
    const { id } = req.params;
    const companyId = req.user!.companyId;

    // Try to find in both collections
    let dataRecord = await FinancialData.findOne({ _id: id, companyId });
    let isFinancial = true;

    if (!dataRecord) {
      dataRecord = await OperationalData.findOne({ _id: id, companyId });
      isFinancial = false;
    }

    if (!dataRecord) {
      throw new AppError('Data record not found', 404);
    }

    // Mark as validated
    dataRecord.metadata.validated = true;
    await dataRecord.save();

    logger.info('Data record validated', {
      recordId: id,
      type: isFinancial ? 'financial' : 'operational',
      companyId,
      userId: req.user!.id,
    });

    res.json({
      success: true,
      message: 'Data validated successfully',
      data: {
        id: dataRecord._id,
        validated: true,
        type: isFinancial ? 'financial' : 'operational',
      },
    });
  } catch (error) {
    logger.error('Error validating data:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Validation failed',
    });
  }
});

// Helper functions

async function parseCSV(buffer: Buffer): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const results: any[] = [];
    const content = buffer.toString('utf-8');
    
    // Basic validation
    if (!content.trim()) {
      reject(new Error('CSV file is empty'));
      return;
    }
    
    const stream = Readable.from(content);
    
    stream
      .pipe(csv())
      .on('data', (data) => results.push(data))
      .on('end', () => {
        if (results.length === 0) {
          reject(new Error('No data rows found in CSV file'));
        } else {
          resolve(results);
        }
      })
      .on('error', (error) => {
        reject(new Error(`CSV parsing error: ${error.message}`));
      });
  });
}

async function parseExcel(buffer: Buffer): Promise<any[]> {
  try {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    
    if (workbook.SheetNames.length === 0) {
      throw new Error('Excel file contains no worksheets');
    }
    
    const sheetName = workbook.SheetNames[0];
    if (!sheetName || !workbook.Sheets[sheetName]) throw new Error('Invalid sheet');
const worksheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(worksheet);
    
    if (data.length === 0) {
      throw new Error('Excel worksheet contains no data');
    }
    
    return data;
  } catch (error) {
    throw new Error(`Excel parsing error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

async function processFinancialData(
  data: any[],
  companyId: string,
  userId: string,
  period: string,
  errors: string[]
): Promise<number> {
  let processedCount = 0;

  for (const row of data) {
    try {
      // Map CSV columns to our financial data structure
      const financialRecord = mapToFinancialData(row, companyId, userId, period);
      
      // Calculate ratios
      financialRecord.ratios = FinancialAnalysisService.calculateFinancialRatios(financialRecord);
      
      // Calculate profitability metrics
      financialRecord.profitability = FinancialAnalysisService.calculateProfitabilityMetrics(
        financialRecord.revenue.total,
        financialRecord.expenses
      );

      await FinancialData.create(financialRecord);
      processedCount++;
    } catch (error) {
      errors.push(`Row ${processedCount + 1}: ${error instanceof Error ? error.message : 'Processing error'}`);
    }
  }

  return processedCount;
}

async function processOperationalData(
  data: any[],
  companyId: string,
  userId: string,
  period: string,
  errors: string[]
): Promise<number> {
  let processedCount = 0;

  for (const row of data) {
    try {
      const operationalRecord = mapToOperationalData(row, companyId, userId, period);
      await OperationalData.create(operationalRecord);
      processedCount++;
    } catch (error) {
      errors.push(`Row ${processedCount + 1}: ${error instanceof Error ? error.message : 'Processing error'}`);
    }
  }

  return processedCount;
}

async function processGenericData(
  data: any[],
  companyId: string,
  userId: string,
  period: string,
  dataType: string,
  errors: string[]
): Promise<number> {
  // For now, store generic data as operational data with specific metadata
  return processOperationalData(data, companyId, userId, period, errors);
}

function mapToFinancialData(row: any, companyId: string, userId: string, period: string): any {
  // This is a simplified mapping - in production, you'd want more sophisticated field mapping
  return {
    companyId,
    date: new Date(row.date || row.Date || Date.now()),
    period,
    revenue: {
      total: parseFloat(row.revenue || row.Revenue || row.total_revenue || 0),
      recurring: parseFloat(row.recurring_revenue || 0),
      oneTime: parseFloat(row.one_time_revenue || 0),
      byProduct: new Map(),
      byRegion: new Map(),
    },
    expenses: {
      total: parseFloat(row.expenses || row.Expenses || row.total_expenses || 0),
      operational: parseFloat(row.operational_expenses || 0),
      marketing: parseFloat(row.marketing_expenses || 0),
      rd: parseFloat(row.rd_expenses || 0),
      administrative: parseFloat(row.admin_expenses || 0),
      other: parseFloat(row.other_expenses || 0),
      breakdown: new Map(),
    },
    balanceSheet: {
      assets: {
        current: parseFloat(row.current_assets || 0),
        fixed: parseFloat(row.fixed_assets || 0),
        total: parseFloat(row.total_assets || 0),
      },
      liabilities: {
        current: parseFloat(row.current_liabilities || 0),
        longTerm: parseFloat(row.long_term_liabilities || 0),
        total: parseFloat(row.total_liabilities || 0),
      },
      equity: parseFloat(row.equity || 0),
    },
    cashFlow: {
      operating: parseFloat(row.operating_cash_flow || 0),
      investing: parseFloat(row.investing_cash_flow || 0),
      financing: parseFloat(row.financing_cash_flow || 0),
      net: parseFloat(row.net_cash_flow || 0),
      endingBalance: parseFloat(row.cash_balance || 0),
    },
    metadata: {
      source: 'csv_upload',
      uploadedBy: userId,
      uploadedAt: new Date(),
      validated: false,
    },
  };
}

function mapToOperationalData(row: any, companyId: string, userId: string, period: string): any {
  return {
    companyId,
    date: new Date(row.date || row.Date || Date.now()),
    period,
    employees: {
      total: parseInt(row.total_employees || row.employees || 0),
      fullTime: parseInt(row.full_time_employees || 0),
      partTime: parseInt(row.part_time_employees || 0),
      contractors: parseInt(row.contractors || 0),
      byDepartment: new Map(),
      turnoverRate: parseFloat(row.turnover_rate || 0),
      productivity: {
        overall: parseFloat(row.productivity || row.employee_productivity || 0),
        byDepartment: new Map(),
      },
    },
    production: {
      output: parseFloat(row.production_output || 0),
      capacity: parseFloat(row.production_capacity || 0),
      utilization: parseFloat(row.capacity_utilization || 0),
      efficiency: parseFloat(row.production_efficiency || 0),
      qualityScore: parseFloat(row.quality_score || 0),
      defectRate: parseFloat(row.defect_rate || 0),
      downtime: parseFloat(row.downtime || 0),
    },
    customers: {
      total: parseInt(row.total_customers || 0),
      new: parseInt(row.new_customers || 0),
      retained: parseInt(row.retained_customers || 0),
      churnRate: parseFloat(row.churn_rate || 0),
      satisfactionScore: parseFloat(row.customer_satisfaction || 0),
      supportTickets: {
        total: parseInt(row.support_tickets || 0),
        resolved: parseInt(row.resolved_tickets || 0),
        avgResolutionTime: parseFloat(row.avg_resolution_time || 0),
      },
    },
    inventory: {
      totalValue: parseFloat(row.inventory_value || 0),
      turnoverRate: parseFloat(row.inventory_turnover || 0),
      stockouts: parseInt(row.stockouts || 0),
      excessStock: parseFloat(row.excess_stock || 0),
      byCategory: new Map(),
    },
    supplyChain: {
      suppliers: {
        total: parseInt(row.total_suppliers || 0),
        active: parseInt(row.active_suppliers || 0),
        performance: new Map(),
      },
      logistics: {
        avgDeliveryTime: parseFloat(row.avg_delivery_time || 0),
        onTimeDeliveryRate: parseFloat(row.on_time_delivery || 0),
        shippingCosts: parseFloat(row.shipping_costs || 0),
        returnRate: parseFloat(row.return_rate || 0),
      },
    },
    technology: {
      systemUptime: parseFloat(row.system_uptime || 0),
      dataProcessingTime: parseFloat(row.data_processing_time || 0),
      securityIncidents: parseInt(row.security_incidents || 0),
      backupSuccess: parseFloat(row.backup_success || 0),
      apiResponseTime: parseFloat(row.api_response_time || 0),
    },
    processes: new Map(),
    metadata: {
      source: 'csv_upload',
      uploadedBy: userId,
      uploadedAt: new Date(),
      validated: false,
    },
  };
}

export default router;