import express from 'express';
import jwt from 'jsonwebtoken';
import { User } from '../models/User';
import { Company } from '../models/Company';
import { validateRequest, schemas } from '../middleware/validation';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key';

/**
 * POST /api/auth/register
 * Register a new user and company
 */
router.post('/register', validateRequest({ body: schemas.register.body }), async (req, res) => {
  try {
    const { email, password, firstName, lastName, companyName, role } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      throw new AppError('User with this email already exists', 409);
    }

    // Create company first
    const company = new Company({
      name: companyName,
      industry: 'Technology', // Default, can be updated later
      size: 'small',
      country: 'US',
      currency: 'USD',
      subscription: {
        plan: 'basic',
        status: 'active',
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days trial
      },
    });

    await company.save();

    // Create user
    const user = new User({
      email,
      password,
      firstName,
      lastName,
      role,
      companyId: company._id,
    });

    await user.save();

    // Generate JWT token
    const token = jwt.sign(
      { 
        id: user._id,
        email: user.email,
        role: user.role,
        companyId: company._id,
      },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    logger.info('User registered successfully', {
      userId: user._id,
      email: user.email,
      companyId: company._id,
    });

    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      data: {
        token,
        user: {
          id: user._id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
        },
        company: {
          id: company._id,
          name: company.name,
          plan: company.subscription.plan,
        },
      },
    });
  } catch (error) {
    logger.error('Registration error:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Registration failed',
    });
  }
});

/**
 * POST /api/auth/login
 * Authenticate user and return JWT token
 */
router.post('/login', validateRequest({ body: schemas.login.body }), async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user and populate company
    const user = await User.findOne({ email, isActive: true }).populate('companyId');
    if (!user) {
      throw new AppError('Invalid email or password', 401);
    }

    // Check password
    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      throw new AppError('Invalid email or password', 401);
    }

    // Update last login
    user.lastLogin = new Date();
    await user.save();

    // Generate JWT token
    const token = jwt.sign(
      { 
        id: user._id,
        email: user.email,
        role: user.role,
        companyId: user.companyId,
      },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    logger.info('User logged in successfully', {
      userId: user._id,
      email: user.email,
      lastLogin: user.lastLogin,
    });

    res.json({
      success: true,
      message: 'Login successful',
      data: {
        token,
        user: {
          id: user._id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
          lastLogin: user.lastLogin,
        },
        company: user.companyId,
      },
    });
  } catch (error) {
    logger.error('Login error:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Login failed',
    });
  }
});

/**
 * POST /api/auth/refresh
 * Refresh JWT token
 */
router.post('/refresh', async (req, res) => {
  try {
    const { token } = req.body;

    if (!token) {
      throw new AppError('Token is required', 400);
    }

    // Verify current token
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    
    // Find user to ensure they still exist and are active
    const user = await User.findById(decoded.id).populate('companyId');
    if (!user || !user.isActive) {
      throw new AppError('User not found or inactive', 401);
    }

    // Generate new token
    const newToken = jwt.sign(
      { 
        id: user._id,
        email: user.email,
        role: user.role,
        companyId: user.companyId,
      },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      success: true,
      message: 'Token refreshed successfully',
      data: {
        token: newToken,
      },
    });
  } catch (error) {
    logger.error('Token refresh error:', error);
    res.status(error instanceof AppError ? error.statusCode : 401).json({
      success: false,
      message: error instanceof Error ? error.message : 'Token refresh failed',
    });
  }
});

/**
 * POST /api/auth/logout
 * Logout user (client-side token removal)
 */
router.post('/logout', (req, res) => {
  // In a stateless JWT system, logout is handled client-side
  // This endpoint exists for consistency and potential future enhancements
  res.json({
    success: true,
    message: 'Logged out successfully',
  });
});

export default router;