import express from 'express';
import { FinancialAnalysisService } from '../services/FinancialAnalysisService';
import { validateRequest, schemas } from '../middleware/validation';
import { AuthenticatedRequest } from '../middleware/auth';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';

const router = express.Router();

/**
 * GET /api/financial/analysis
 * Get financial analysis for a specific period
 */
router.get('/analysis', validateRequest({ query: schemas.financialAnalysis.query }), async (req: AuthenticatedRequest, res) => {
  try {
    const { startDate, endDate, period, metrics } = req.query as any;
    const companyId = req.user!.companyId;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 365 * 24 * 60 * 60 * 1000); // Default: 1 year ago
    const end = endDate ? new Date(endDate) : new Date();

    const analysis = await FinancialAnalysisService.generateFinancialSummary(companyId, start, end);

    res.json({
      success: true,
      data: analysis,
    });
  } catch (error) {
    logger.error('Error in financial analysis endpoint:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * GET /api/financial/trends
 * Get financial trends over time
 */
router.get('/trends', async (req: AuthenticatedRequest, res) => {
  try {
    const { startDate, endDate, period = 'monthly' } = req.query as any;
    const companyId = req.user!.companyId;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 365 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();

    const trends = await FinancialAnalysisService.getFinancialTrends(companyId, start, end, period);

    res.json({
      success: true,
      data: trends,
    });
  } catch (error) {
    logger.error('Error in financial trends endpoint:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * GET /api/financial/health
 * Get financial health assessment
 */
router.get('/health', async (req: AuthenticatedRequest, res) => {
  try {
    const { date } = req.query as any;
    const companyId = req.user!.companyId;

    const assessmentDate = date ? new Date(date) : new Date();
    const healthAssessment = await FinancialAnalysisService.assessFinancialHealth(companyId, assessmentDate);

    res.json({
      success: true,
      data: healthAssessment,
    });
  } catch (error) {
    logger.error('Error in financial health endpoint:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * GET /api/financial/ratios
 * Get financial ratios for a specific period
 */
router.get('/ratios', async (req: AuthenticatedRequest, res) => {
  try {
    const { startDate, endDate } = req.query as any;
    const companyId = req.user!.companyId;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 90 * 24 * 60 * 60 * 1000); // Default: 3 months ago
    const end = endDate ? new Date(endDate) : new Date();

    const summary = await FinancialAnalysisService.generateFinancialSummary(companyId, start, end);

    res.json({
      success: true,
      data: {
        current: summary.current.ratios,
        trends: summary.trends,
        period: summary.period,
      },
    });
  } catch (error) {
    logger.error('Error in financial ratios endpoint:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * GET /api/financial/breakdown
 * Get revenue and expense breakdown
 */
router.get('/breakdown', async (req: AuthenticatedRequest, res) => {
  try {
    const { startDate, endDate, type = 'both' } = req.query as any;
    const companyId = req.user!.companyId;

    const start = startDate ? new Date(startDate) : new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
    const end = endDate ? new Date(endDate) : new Date();

    const summary = await FinancialAnalysisService.generateFinancialSummary(companyId, start, end);

    const breakdown: any = {};

    if (type === 'revenue' || type === 'both') {
      breakdown.revenue = {
        total: summary.current.revenue,
        breakdown: summary.periodTotals.revenue,
        trends: summary.trends.revenue,
      };
    }

    if (type === 'expenses' || type === 'both') {
      breakdown.expenses = {
        total: summary.current.expenses,
        breakdown: summary.periodTotals.expenses,
        trends: summary.trends.expenses,
      };
    }

    res.json({
      success: true,
      data: breakdown,
    });
  } catch (error) {
    logger.error('Error in financial breakdown endpoint:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

export default router;