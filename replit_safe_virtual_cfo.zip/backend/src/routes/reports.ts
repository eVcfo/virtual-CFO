import express from 'express';
import { ReportService } from '../services/ReportService';
import { validateRequest, schemas } from '../middleware/validation';
import { AuthenticatedRequest } from '../middleware/auth';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';

const router = express.Router();

/**
 * POST /api/reports/generate
 * Generate a custom report
 */
router.post('/generate', validateRequest({ body: schemas.reportGeneration.body }), async (req: AuthenticatedRequest, res) => {
  try {
    const companyId = req.user!.companyId;
    const userId = req.user!.id;
    const { reportType, dateRange, sections, format } = req.body;

    const report = await ReportService.generateReport(companyId, userId, {
      reportType,
      dateRange,
      sections,
      format,
    });

    res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    logger.error('Error generating report:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * GET /api/reports/list
 * Get list of generated reports
 */
router.get('/list', async (req: AuthenticatedRequest, res) => {
  try {
    const companyId = req.user!.companyId;
    const { limit = 20, offset = 0 } = req.query as any;

    const reports = await ReportService.getReportsList(companyId, parseInt(limit), parseInt(offset));

    res.json({
      success: true,
      data: reports,
    });
  } catch (error) {
    logger.error('Error fetching reports list:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

/**
 * GET /api/reports/:id/download
 * Download a generated report
 */
router.get('/:id/download', async (req: AuthenticatedRequest, res) => {
  try {
    const { id } = req.params;
    const companyId = req.user!.companyId;

    const reportData = await ReportService.downloadReport(companyId, id);

    res.setHeader('Content-Type', reportData.contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${reportData.filename}"`);
    res.send(reportData.buffer);
  } catch (error) {
    logger.error('Error downloading report:', error);
    res.status(error instanceof AppError ? error.statusCode : 500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Internal server error',
    });
  }
});

export default router;