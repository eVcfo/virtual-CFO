import mongoose, { Document, Schema } from 'mongoose';

export interface ICompany extends Document {
  name: string;
  industry: string;
  size: 'startup' | 'small' | 'medium' | 'large' | 'enterprise';
  country: string;
  currency: string;
  fiscalYearStart: number; // Month (1-12)
  settings: {
    dataRetentionMonths: number;
    autoBackup: boolean;
    notifications: {
      email: boolean;
      dashboard: boolean;
    };
  };
  subscription: {
    plan: 'basic' | 'professional' | 'enterprise';
    status: 'active' | 'suspended' | 'cancelled';
    expiresAt: Date;
  };
  createdAt: Date;
  updatedAt: Date;
}

const companySchema = new Schema<ICompany>({
  name: {
    type: String,
    required: true,
    trim: true,
    maxlength: 100,
    index: true,
  },
  industry: {
    type: String,
    required: true,
    trim: true,
    maxlength: 50,
  },
  size: {
    type: String,
    enum: ['startup', 'small', 'medium', 'large', 'enterprise'],
    required: true,
  },
  country: {
    type: String,
    required: true,
    length: 2, // ISO country code
  },
  currency: {
    type: String,
    required: true,
    length: 3, // ISO currency code
    default: 'USD',
  },
  fiscalYearStart: {
    type: Number,
    min: 1,
    max: 12,
    default: 1, // January
  },
  settings: {
    dataRetentionMonths: {
      type: Number,
      default: 36,
      min: 12,
      max: 120,
    },
    autoBackup: {
      type: Boolean,
      default: true,
    },
    notifications: {
      email: {
        type: Boolean,
        default: true,
      },
      dashboard: {
        type: Boolean,
        default: true,
      },
    },
  },
  subscription: {
    plan: {
      type: String,
      enum: ['basic', 'professional', 'enterprise'],
      default: 'basic',
    },
    status: {
      type: String,
      enum: ['active', 'suspended', 'cancelled'],
      default: 'active',
    },
    expiresAt: {
      type: Date,
      required: true,
    },
  },
}, {
  timestamps: true,
});

export const Company = mongoose.model<ICompany>('Company', companySchema);