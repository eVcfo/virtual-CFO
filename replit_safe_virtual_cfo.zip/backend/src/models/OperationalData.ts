import mongoose, { Document, Schema } from 'mongoose';

export interface IOperationalData extends Document {
  companyId: mongoose.Types.ObjectId;
  date: Date;
  period: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly';
  
  // Employee metrics
  employees: {
    total: number;
    fullTime: number;
    partTime: number;
    contractors: number;
    byDepartment: Map<string, number>;
    turnoverRate: number;
    productivity: {
      overall: number;
      byDepartment: Map<string, number>;
    };
  };
  
  // Production metrics
  production: {
    output: number;
    capacity: number;
    utilization: number;
    efficiency: number;
    qualityScore: number;
    defectRate: number;
    downtime: number;
  };
  
  // Customer metrics
  customers: {
    total: number;
    new: number;
    retained: number;
    churnRate: number;
    satisfactionScore: number;
    supportTickets: {
      total: number;
      resolved: number;
      avgResolutionTime: number;
    };
  };
  
  // Inventory metrics
  inventory: {
    totalValue: number;
    turnoverRate: number;
    stockouts: number;
    excessStock: number;
    byCategory: Map<string, {
      quantity: number;
      value: number;
      turnover: number;
    }>;
  };
  
  // Supply chain metrics
  supplyChain: {
    suppliers: {
      total: number;
      active: number;
      performance: Map<string, {
        onTimeDelivery: number;
        qualityScore: number;
        costEfficiency: number;
      }>;
    };
    logistics: {
      avgDeliveryTime: number;
      onTimeDeliveryRate: number;
      shippingCosts: number;
      returnRate: number;
    };
  };
  
  // Technology metrics
  technology: {
    systemUptime: number;
    dataProcessingTime: number;
    securityIncidents: number;
    backupSuccess: number;
    apiResponseTime: number;
  };
  
  // Process efficiency
  processes: Map<string, {
    efficiency: number;
    cycleTime: number;
    errorRate: number;
    cost: number;
    bottlenecks: string[];
  }>;
  
  metadata: {
    source: string;
    uploadedBy: mongoose.Types.ObjectId;
    uploadedAt: Date;
    validated: boolean;
    notes?: string;
  };
  
  createdAt: Date;
  updatedAt: Date;
}

const operationalDataSchema = new Schema<IOperationalData>({
  companyId: {
    type: Schema.Types.ObjectId,
    ref: 'Company',
    required: true,
    index: true,
  },
  date: {
    type: Date,
    required: true,
    index: true,
  },
  period: {
    type: String,
    enum: ['daily', 'weekly', 'monthly', 'quarterly', 'yearly'],
    required: true,
  },
  
  employees: {
    total: { type: Number, required: true, min: 0 },
    fullTime: { type: Number, default: 0, min: 0 },
    partTime: { type: Number, default: 0, min: 0 },
    contractors: { type: Number, default: 0, min: 0 },
    byDepartment: { type: Map, of: Number, default: new Map() },
    turnoverRate: { type: Number, min: 0, max: 100 },
    productivity: {
      overall: { type: Number, min: 0, max: 100 },
      byDepartment: { type: Map, of: Number, default: new Map() },
    },
  },
  
  production: {
    output: { type: Number, min: 0 },
    capacity: { type: Number, min: 0 },
    utilization: { type: Number, min: 0, max: 100 },
    efficiency: { type: Number, min: 0, max: 100 },
    qualityScore: { type: Number, min: 0, max: 100 },
    defectRate: { type: Number, min: 0, max: 100 },
    downtime: { type: Number, min: 0 },
  },
  
  customers: {
    total: { type: Number, min: 0 },
    new: { type: Number, min: 0 },
    retained: { type: Number, min: 0 },
    churnRate: { type: Number, min: 0, max: 100 },
    satisfactionScore: { type: Number, min: 0, max: 10 },
    supportTickets: {
      total: { type: Number, min: 0 },
      resolved: { type: Number, min: 0 },
      avgResolutionTime: { type: Number, min: 0 },
    },
  },
  
  inventory: {
    totalValue: { type: Number, min: 0 },
    turnoverRate: { type: Number, min: 0 },
    stockouts: { type: Number, min: 0 },
    excessStock: { type: Number, min: 0 },
    byCategory: {
      type: Map,
      of: {
        quantity: { type: Number, min: 0 },
        value: { type: Number, min: 0 },
        turnover: { type: Number, min: 0 },
      },
      default: new Map(),
    },
  },
  
  supplyChain: {
    suppliers: {
      total: { type: Number, min: 0 },
      active: { type: Number, min: 0 },
      performance: {
        type: Map,
        of: {
          onTimeDelivery: { type: Number, min: 0, max: 100 },
          qualityScore: { type: Number, min: 0, max: 100 },
          costEfficiency: { type: Number, min: 0, max: 100 },
        },
        default: new Map(),
      },
    },
    logistics: {
      avgDeliveryTime: { type: Number, min: 0 },
      onTimeDeliveryRate: { type: Number, min: 0, max: 100 },
      shippingCosts: { type: Number, min: 0 },
      returnRate: { type: Number, min: 0, max: 100 },
    },
  },
  
  technology: {
    systemUptime: { type: Number, min: 0, max: 100 },
    dataProcessingTime: { type: Number, min: 0 },
    securityIncidents: { type: Number, min: 0 },
    backupSuccess: { type: Number, min: 0, max: 100 },
    apiResponseTime: { type: Number, min: 0 },
  },
  
  processes: {
    type: Map,
    of: {
      efficiency: { type: Number, min: 0, max: 100 },
      cycleTime: { type: Number, min: 0 },
      errorRate: { type: Number, min: 0, max: 100 },
      cost: { type: Number, min: 0 },
      bottlenecks: [{ type: String }],
    },
    default: new Map(),
  },
  
  metadata: {
    source: { type: String, required: true },
    uploadedBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    uploadedAt: { type: Date, default: Date.now },
    validated: { type: Boolean, default: false },
    notes: { type: String, maxlength: 500 },
  },
}, {
  timestamps: true,
});

// Compound indexes for efficient queries
operationalDataSchema.index({ companyId: 1, date: -1 });
operationalDataSchema.index({ companyId: 1, period: 1, date: -1 });
operationalDataSchema.index({ companyId: 1, 'metadata.validated': 1, date: -1 });

export const OperationalData = mongoose.model<IOperationalData>('OperationalData', operationalDataSchema);