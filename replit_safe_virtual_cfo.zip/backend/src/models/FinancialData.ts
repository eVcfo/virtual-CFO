import mongoose, { Document, Schema } from 'mongoose';

export interface IFinancialData extends Document {
  companyId: mongoose.Types.ObjectId;
  date: Date;
  period: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly';
  
  // Revenue metrics
  revenue: {
    total: number;
    recurring: number;
    oneTime: number;
    byProduct: Map<string, number>;
    byRegion: Map<string, number>;
  };
  
  // Expense metrics
  expenses: {
    total: number;
    operational: number;
    marketing: number;
    rd: number;
    administrative: number;
    other: number;
    breakdown: Map<string, number>;
  };
  
  // Profitability metrics
  profitability: {
    grossProfit: number;
    netProfit: number;
    ebitda: number;
    margins: {
      gross: number;
      net: number;
      ebitda: number;
    };
  };
  
  // Balance sheet data
  balanceSheet: {
    assets: {
      current: number;
      fixed: number;
      total: number;
    };
    liabilities: {
      current: number;
      longTerm: number;
      total: number;
    };
    equity: number;
  };
  
  // Cash flow data
  cashFlow: {
    operating: number;
    investing: number;
    financing: number;
    net: number;
    endingBalance: number;
  };
  
  // Key ratios
  ratios: {
    liquidity: {
      current: number;
      quick: number;
      cash: number;
    };
    profitability: {
      roa: number; // Return on Assets
      roe: number; // Return on Equity
      roic: number; // Return on Invested Capital
    };
    efficiency: {
      assetTurnover: number;
      inventoryTurnover: number;
      receivablesTurnover: number;
    };
    leverage: {
      debtToEquity: number;
      debtToAssets: number;
      interestCoverage: number;
    };
  };
  
  metadata: {
    source: string;
    uploadedBy: mongoose.Types.ObjectId;
    uploadedAt: Date;
    validated: boolean;
    notes?: string;
  };
  
  createdAt: Date;
  updatedAt: Date;
}

const financialDataSchema = new Schema<IFinancialData>({
  companyId: {
    type: Schema.Types.ObjectId,
    ref: 'Company',
    required: true,
    index: true,
  },
  date: {
    type: Date,
    required: true,
    index: true,
  },
  period: {
    type: String,
    enum: ['daily', 'weekly', 'monthly', 'quarterly', 'yearly'],
    required: true,
  },
  
  revenue: {
    total: { type: Number, required: true, min: 0 },
    recurring: { type: Number, default: 0, min: 0 },
    oneTime: { type: Number, default: 0, min: 0 },
    byProduct: { type: Map, of: Number, default: new Map() },
    byRegion: { type: Map, of: Number, default: new Map() },
  },
  
  expenses: {
    total: { type: Number, required: true, min: 0 },
    operational: { type: Number, default: 0, min: 0 },
    marketing: { type: Number, default: 0, min: 0 },
    rd: { type: Number, default: 0, min: 0 },
    administrative: { type: Number, default: 0, min: 0 },
    other: { type: Number, default: 0, min: 0 },
    breakdown: { type: Map, of: Number, default: new Map() },
  },
  
  profitability: {
    grossProfit: { type: Number, required: true },
    netProfit: { type: Number, required: true },
    ebitda: { type: Number, required: true },
    margins: {
      gross: { type: Number, required: true, min: -100, max: 100 },
      net: { type: Number, required: true, min: -100, max: 100 },
      ebitda: { type: Number, required: true, min: -100, max: 100 },
    },
  },
  
  balanceSheet: {
    assets: {
      current: { type: Number, default: 0, min: 0 },
      fixed: { type: Number, default: 0, min: 0 },
      total: { type: Number, required: true, min: 0 },
    },
    liabilities: {
      current: { type: Number, default: 0, min: 0 },
      longTerm: { type: Number, default: 0, min: 0 },
      total: { type: Number, required: true, min: 0 },
    },
    equity: { type: Number, required: true },
  },
  
  cashFlow: {
    operating: { type: Number, required: true },
    investing: { type: Number, default: 0 },
    financing: { type: Number, default: 0 },
    net: { type: Number, required: true },
    endingBalance: { type: Number, required: true, min: 0 },
  },
  
  ratios: {
    liquidity: {
      current: { type: Number, min: 0 },
      quick: { type: Number, min: 0 },
      cash: { type: Number, min: 0 },
    },
    profitability: {
      roa: { type: Number, min: -100, max: 100 },
      roe: { type: Number, min: -100, max: 100 },
      roic: { type: Number, min: -100, max: 100 },
    },
    efficiency: {
      assetTurnover: { type: Number, min: 0 },
      inventoryTurnover: { type: Number, min: 0 },
      receivablesTurnover: { type: Number, min: 0 },
    },
    leverage: {
      debtToEquity: { type: Number, min: 0 },
      debtToAssets: { type: Number, min: 0, max: 1 },
      interestCoverage: { type: Number },
    },
  },
  
  metadata: {
    source: { type: String, required: true },
    uploadedBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    uploadedAt: { type: Date, default: Date.now },
    validated: { type: Boolean, default: false },
    notes: { type: String, maxlength: 500 },
  },
}, {
  timestamps: true,
});

// Compound indexes for efficient queries
financialDataSchema.index({ companyId: 1, date: -1 });
financialDataSchema.index({ companyId: 1, period: 1, date: -1 });
financialDataSchema.index({ companyId: 1, 'metadata.validated': 1, date: -1 });

export const FinancialData = mongoose.model<IFinancialData>('FinancialData', financialDataSchema);